const fetch = require('node-fetch');

exports.handler = async (event, context) => {
  // Configuration CORS
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  };

  // Gérer les requêtes OPTIONS (preflight)
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers,
      body: '',
    };
  }

  // Vérifier que c'est une requête POST
  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: 'Méthode non autorisée' }),
    };
  }

  try {
    // Parser le body de la requête
    const { messages, userProfile, context: requestContext } = JSON.parse(event.body || '{}');

    // Vérifier que les messages sont fournis
    if (!messages || !Array.isArray(messages)) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: 'Messages requis' }),
      };
    }

    // Récupérer la clé API depuis les variables d'environnement
    const openaiApiKey = process.env.OPENAI_API_KEY;
    
    if (!openaiApiKey) {
      console.error('Clé API OpenAI manquante');
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({ 
          error: 'Configuration serveur incomplète',
          details: 'Clé API OpenAI non configurée'
        }),
      };
    }

    // Log pour debug (sans exposer la clé)
    console.log('Requête reçue:', {
      messagesCount: messages.length,
      hasUserProfile: !!userProfile,
      hasContext: !!requestContext,
      apiKeyConfigured: !!openaiApiKey
    });

    // Construire le prompt système adapté au profil juridique
    const systemPrompt = buildJuridicalSystemPrompt(userProfile, requestContext);

    // Préparer les messages pour OpenAI
    const openaiMessages = [
      {
        role: 'system',
        content: systemPrompt
      },
      ...messages
    ];

    // Appel à l'API OpenAI
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${openaiApiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-4',
        messages: openaiMessages,
        max_tokens: 2000,
        temperature: 0.3,
        top_p: 1,
        frequency_penalty: 0,
        presence_penalty: 0,
      }),
    });

    const data = await response.json();

    if (!response.ok) {
      console.error('Erreur OpenAI:', data);
      return {
        statusCode: response.status,
        headers,
        body: JSON.stringify({ 
          error: 'Erreur API OpenAI', 
          details: data.error?.message || 'Erreur inconnue',
          code: data.error?.code || 'unknown'
        }),
      };
    }

    // Extraire la réponse
    const aiResponse = data.choices[0]?.message?.content || 'Aucune réponse générée';

    console.log('Réponse OpenAI générée avec succès');

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        response: aiResponse,
        usage: data.usage,
        model: data.model,
        timestamp: new Date().toISOString()
      }),
    };

  } catch (error) {
    console.error('Erreur dans askGPT:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ 
        error: 'Erreur serveur', 
        details: error.message 
      }),
    };
  }
};

// Fonction pour construire le prompt système adapté au profil juridique
function buildJuridicalSystemPrompt(userProfile, context) {
  const basePrompt = `Tu es un assistant juridique IA expert, spécialisé dans le droit français. Tu aides des professionnels du droit et des étudiants.

CONTEXTE JURIDIQUE :
- Tu maîtrises parfaitement le Code civil, le Code pénal, le Code du travail, et toute la législation française
- Tu connais la jurisprudence récente des cours d'appel et de la Cour de cassation
- Tu adaptes tes réponses selon le profil de l'utilisateur (étudiant, avocat, juriste, etc.)
- Tu cites toujours tes sources légales et jurisprudentielles quand c'est pertinent`;
  
  let profileContext = '';
  
  if (userProfile) {
    const { status, legalDomains, writingStyle, location } = userProfile;
    
    // Adaptation selon le statut
    if (status === 'Étudiant en droit') {
      profileContext += `\n\nPROFIL UTILISATEUR : Étudiant en droit
- Adapte tes réponses pour être pédagogiques
- Explique les concepts juridiques de base
- Donne des exemples concrets et des références aux cours
- Utilise un langage accessible mais précis`;
    } else if (status === 'Avocat') {
      profileContext += `\n\nPROFIL UTILISATEUR : Avocat
- Fournis des réponses professionnelles de haut niveau
- Inclus des références jurisprudentielles précises
- Donne des conseils pratiques pour la plaidoirie
- Mentionne les stratégies procédurales pertinentes`;
    } else if (status === 'Juriste d\'entreprise') {
      profileContext += `\n\nPROFIL UTILISATEUR : Juriste d'entreprise
- Concentre-toi sur les aspects pratiques et business
- Évalue les risques juridiques pour l'entreprise
- Propose des solutions pragmatiques
- Considère l'impact économique des décisions juridiques`;
    } else if (status === 'Notaire') {
      profileContext += `\n\nPROFIL UTILISATEUR : Notaire
- Focus sur le droit immobilier, familial et des successions
- Expertise en rédaction d'actes authentiques
- Connaissance approfondie du droit patrimonial
- Conseil en optimisation fiscale légale`;
    }
    
    // Adaptation selon les domaines juridiques
    if (legalDomains && legalDomains.length > 0) {
      profileContext += `\n\nDOMAINES D'EXPERTISE : ${legalDomains.join(', ')}
- Privilégie ces domaines dans tes réponses
- Approfondit les aspects spécifiques à ces spécialités
- Fais des liens entre les différents domaines si pertinent`;
    }
    
    // Adaptation selon le style de rédaction
    if (writingStyle === 'formal') {
      profileContext += `\n\nSTYLE DE RÉDACTION : Formel et structuré
- Utilise un langage juridique précis et technique
- Structure tes réponses avec des titres et sous-titres
- Adopte le style des actes juridiques professionnels`;
    } else if (writingStyle === 'synthetic') {
      profileContext += `\n\nSTYLE DE RÉDACTION : Synthétique et concis
- Sois direct et va à l'essentiel
- Utilise des listes à puces pour clarifier
- Évite les développements trop longs`;
    } else if (writingStyle === 'detailed') {
      profileContext += `\n\nSTYLE DE RÉDACTION : Détaillé avec références
- Inclus de nombreuses citations légales et jurisprudentielles
- Développe tous les aspects de la question
- Donne des références précises (articles, arrêts, dates)`;
    } else if (writingStyle === 'pedagogical') {
      profileContext += `\n\nSTYLE DE RÉDACTION : Pédagogique et explicatif
- Explique les concepts étape par étape
- Donne des exemples concrets et des cas pratiques
- Utilise des analogies pour clarifier les points complexes`;
    }
    
    // Localisation
    if (location) {
      profileContext += `\n\nLOCALISATION : ${location}
- Tiens compte des spécificités locales si pertinentes
- Mentionne les juridictions compétentes locales
- Considère les usages locaux en matière juridique`;
    }
  }
  
  // Contexte additionnel selon le module
  let contextInfo = '';
  if (context) {
    if (context.module === 'preparation-rdv') {
      contextInfo += `\n\nCONTEXTE : Préparation de rendez-vous client
- Aide à structurer la consultation
- Identifie les points clés à aborder
- Propose des questions à poser au client
- Suggère les documents à demander`;
    } else if (context.module === 'redaction-acte') {
      contextInfo += `\n\nCONTEXTE : Rédaction d'acte juridique
- Aide à la rédaction professionnelle
- Respecte les formes et usages juridiques
- Inclus les mentions obligatoires
- Structure selon les standards du barreau`;
    } else if (context.module === 'dashboard') {
      contextInfo += `\n\nCONTEXTE : Assistant juridique général
- Réponds aux questions juridiques variées
- Donne des conseils pratiques
- Oriente vers les bonnes procédures`;
    }
  }
  
  const guidelines = `

RÈGLES IMPORTANTES :
✅ Réponds UNIQUEMENT sur des questions juridiques
✅ Base-toi sur le droit français en vigueur (2024-2025)
✅ Cite tes sources (articles de loi, jurisprudence) avec précision
✅ Si tu n'es pas sûr d'une information, dis-le clairement
✅ Ne donne jamais de conseils personnalisés sans préciser les limites
✅ Reste professionnel et précis dans tes réponses
✅ Adapte ton niveau de langage au profil de l'utilisateur
✅ Mentionne quand une consultation avec un avocat est recommandée

❌ Ne réponds pas aux questions non-juridiques
❌ N'invente jamais de références légales
❌ Ne donne pas de conseils médicaux, financiers ou autres
❌ Ne prends pas position sur des questions politiques`;

  return basePrompt + profileContext + contextInfo + guidelines;
}