exports.handler = async (event, context) => {
  // Configuration CORS
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  };

  // Gérer les requêtes OPTIONS (preflight)
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers,
      body: '',
    };
  }

  // Vérifier que c'est une requête POST
  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: 'Méthode non autorisée' }),
    };
  }

  try {
    // Parser le body de la requête
    const { messages, userProfile, context: requestContext } = JSON.parse(event.body);

    // Vérifier que les messages sont fournis
    if (!messages || !Array.isArray(messages)) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: 'Messages requis' }),
      };
    }

    // Récupérer la clé API depuis les variables d'environnement
    const openaiApiKey = process.env.OPENAI_API_KEY;
    
    if (!openaiApiKey) {
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({ error: 'Clé API OpenAI non configurée' }),
      };
    }

    // Construire le prompt système adapté au profil juridique
    const systemPrompt = buildJuridicalSystemPrompt(userProfile, requestContext);

    // Préparer les messages pour OpenAI
    const openaiMessages = [
      {
        role: 'system',
        content: systemPrompt
      },
      ...messages
    ];

    // Appel à l'API OpenAI avec fetch natif (disponible dans Node.js 18+)
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${openaiApiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-4',
        messages: openaiMessages,
        max_tokens: 2000,
        temperature: 0.3,
        top_p: 1,
        frequency_penalty: 0,
        presence_penalty: 0,
      }),
    });

    const data = await response.json();

    if (!response.ok) {
      console.error('Erreur OpenAI:', data);
      return {
        statusCode: response.status,
        headers,
        body: JSON.stringify({ 
          error: 'Erreur API OpenAI', 
          details: data.error?.message || 'Erreur inconnue' 
        }),
      };
    }

    // Extraire la réponse
    const aiResponse = data.choices[0]?.message?.content || 'Aucune réponse générée';

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        response: aiResponse,
        usage: data.usage,
        model: data.model,
        timestamp: new Date().toISOString()
      }),
    };

  } catch (error) {
    console.error('Erreur dans askGPT:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ 
        error: 'Erreur serveur', 
        details: error.message 
      }),
    };
  }
};

// Fonction pour construire le prompt système adapté au profil juridique
function buildJuridicalSystemPrompt(userProfile, context) {
  const basePrompt = `Tu es un assistant juridique IA expert, spécialisé dans le droit français. Tu aides des professionnels du droit et des étudiants.`;
  
  let profileContext = '';
  
  if (userProfile) {
    const { status, legalDomains, writingStyle, location } = userProfile;
    
    // Adaptation selon le statut
    if (status === 'Étudiant en droit') {
      profileContext += `\nL'utilisateur est étudiant en droit. Adapte tes réponses pour être pédagogiques, avec des explications claires et des références aux cours de base.`;
    } else if (status === 'Avocat') {
      profileContext += `\nL'utilisateur est avocat. Fournis des réponses professionnelles avec des références jurisprudentielles et des conseils pratiques.`;
    } else if (status === 'Juriste d\'entreprise') {
      profileContext += `\nL'utilisateur est juriste d'entreprise. Concentre-toi sur les aspects pratiques et les risques business.`;
    }
    
    // Adaptation selon les domaines juridiques
    if (legalDomains && legalDomains.length > 0) {
      profileContext += `\nDomaines d'expertise de l'utilisateur : ${legalDomains.join(', ')}. Privilégie ces domaines dans tes réponses.`;
    }
    
    // Adaptation selon le style de rédaction
    if (writingStyle === 'formal') {
      profileContext += `\nStyle préféré : formel et structuré. Utilise un langage juridique précis.`;
    } else if (writingStyle === 'synthetic') {
      profileContext += `\nStyle préféré : synthétique et concis. Sois direct et va à l'essentiel.`;
    } else if (writingStyle === 'detailed') {
      profileContext += `\nStyle préféré : détaillé avec références. Inclus des citations légales et jurisprudentielles.`;
    } else if (writingStyle === 'pedagogical') {
      profileContext += `\nStyle préféré : pédagogique. Explique les concepts et donne des exemples.`;
    }
    
    // Localisation
    if (location) {
      profileContext += `\nLocalisation : ${location}. Tiens compte des spécificités locales si pertinentes.`;
    }
  }
  
  // Contexte additionnel
  let contextInfo = '';
  if (context) {
    if (context.module === 'preparation-rdv') {
      contextInfo += `\nContexte : préparation de rendez-vous client. Aide à structurer la consultation.`;
    } else if (context.module === 'redaction-acte') {
      contextInfo += `\nContexte : rédaction d'acte juridique. Aide à la rédaction professionnelle.`;
    }
  }
  
  const guidelines = `

RÈGLES IMPORTANTES :
- Réponds uniquement sur des questions juridiques
- Base-toi sur le droit français en vigueur
- Cite tes sources (articles de loi, jurisprudence) quand possible
- Si tu n'es pas sûr, dis-le clairement
- Ne donne jamais de conseils personnalisés sans préciser les limites
- Reste professionnel et précis
- Adapte ton niveau de langage au profil de l'utilisateur`;

  return basePrompt + profileContext + contextInfo + guidelines;
}