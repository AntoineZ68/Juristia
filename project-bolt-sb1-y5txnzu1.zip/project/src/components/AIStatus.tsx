import React, { useState, useEffect } from 'react';
import { CheckCircle, AlertCircle, Loader2, RefreshCw } from 'lucide-react';
import { testAIConnection } from '../services/aiService';

interface AIStatusProps {
  className?: string;
}

const AIStatus: React.FC<AIStatusProps> = ({ className = '' }) => {
  const [status, setStatus] = useState<'checking' | 'connected' | 'error'>('checking');
  const [message, setMessage] = useState('Vérification de la connexion IA...');
  const [lastCheck, setLastCheck] = useState<Date | null>(null);

  useEffect(() => {
    checkAIConnection();
    
    // Vérification automatique toutes les 5 minutes
    const interval = setInterval(checkAIConnection, 5 * 60 * 1000);
    return () => clearInterval(interval);
  }, []);

  const checkAIConnection = async () => {
    setStatus('checking');
    setMessage('Test de connexion OpenAI...');
    
    try {
      const isConnected = await testAIConnection();
      
      if (isConnected) {
        setStatus('connected');
        setMessage('IA OpenAI connectée et opérationnelle');
      } else {
        setStatus('error');
        setMessage('Connexion IA échouée - Réponse invalide');
      }
    } catch (error) {
      setStatus('error');
      
      if (error instanceof Error) {
        if (error.message.includes('Configuration OpenAI manquante')) {
          setMessage('Variables d\'environnement Netlify non configurées');
        } else if (error.message.includes('Fonction Netlify non trouvée')) {
          setMessage('Fonction Netlify non déployée');
        } else if (error.message.includes('Failed to fetch')) {
          setMessage('Impossible de contacter le serveur');
        } else {
          setMessage(`Erreur: ${error.message}`);
        }
      } else {
        setMessage('Erreur de connexion inconnue');
      }
    }
    
    setLastCheck(new Date());
  };

  const getStatusIcon = () => {
    switch (status) {
      case 'checking':
        return <Loader2 className="h-4 w-4 animate-spin text-blue-500" />;
      case 'connected':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'error':
        return <AlertCircle className="h-4 w-4 text-red-500" />;
    }
  };

  const getStatusColor = () => {
    switch (status) {
      case 'checking':
        return 'text-blue-600';
      case 'connected':
        return 'text-green-600';
      case 'error':
        return 'text-red-600';
    }
  };

  const getStatusBg = () => {
    switch (status) {
      case 'checking':
        return 'bg-blue-50 border-blue-200';
      case 'connected':
        return 'bg-green-50 border-green-200';
      case 'error':
        return 'bg-red-50 border-red-200';
    }
  };

  return (
    <div className={`flex items-center justify-between p-3 rounded-lg border ${getStatusBg()} ${className}`}>
      <div className="flex items-center space-x-3">
        {getStatusIcon()}
        <div>
          <span className={`text-sm font-medium ${getStatusColor()}`}>
            {message}
          </span>
          {lastCheck && (
            <p className="text-xs text-gray-500 mt-1">
              Dernière vérification: {lastCheck.toLocaleTimeString()}
            </p>
          )}
        </div>
      </div>
      
      <div className="flex items-center space-x-2">
        {status === 'error' && (
          <button
            onClick={checkAIConnection}
            disabled={status === 'checking'}
            className="inline-flex items-center px-3 py-1 text-xs bg-red-100 text-red-700 rounded-md hover:bg-red-200 transition-colors duration-200 disabled:opacity-50"
          >
            <RefreshCw className={`h-3 w-3 mr-1 ${status === 'checking' ? 'animate-spin' : ''}`} />
            Réessayer
          </button>
        )}
        
        {status === 'connected' && (
          <button
            onClick={checkAIConnection}
            disabled={status === 'checking'}
            className="inline-flex items-center px-3 py-1 text-xs bg-green-100 text-green-700 rounded-md hover:bg-green-200 transition-colors duration-200 disabled:opacity-50"
          >
            <RefreshCw className={`h-3 w-3 mr-1 ${status === 'checking' ? 'animate-spin' : ''}`} />
            Tester
          </button>
        )}
      </div>
    </div>
  );
};

export default AIStatus;