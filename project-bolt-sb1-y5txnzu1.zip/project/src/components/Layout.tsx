import React from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { Scale, FileText, Calendar, Download, Menu, X, LogOut, User } from 'lucide-react';

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  const location = useLocation();
  const navigate = useNavigate();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = React.useState(false);
  const [isUserMenuOpen, setIsUserMenuOpen] = React.useState(false);

  // Get user info from localStorage
  const user = JSON.parse(localStorage.getItem('juristia_user') || '{}');

  const navigation = [
    { name: 'Dashboard', href: '/dashboard', icon: Scale },
    { name: 'Préparation RDV', href: '/preparation-rdv', icon: Calendar },
    { name: 'Rédaction d\'acte', href: '/redaction-acte', icon: FileText },
    { name: 'Export', href: '/export', icon: Download },
  ];

  const handleLogout = () => {
    localStorage.removeItem('juristia_auth');
    localStorage.removeItem('juristia_user');
    navigate('/');
  };

  return (
    <div className="min-h-screen bg-legal-50">
      {/* Header */}
      <header className="bg-white border-b border-legal-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Logo */}
            <div className="flex items-center">
              <Link to="/dashboard" className="flex-shrink-0 flex items-center hover:opacity-80 transition-opacity duration-200">
                <Scale className="h-8 w-8 text-primary-600" />
                <span className="ml-2 text-xl font-bold text-legal-900">Juristia</span>
              </Link>
            </div>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex space-x-8">
              {navigation.map((item) => {
                const Icon = item.icon;
                const isActive = location.pathname === item.href;
                return (
                  <Link
                    key={item.name}
                    to={item.href}
                    className={`flex items-center px-3 py-2 rounded-md text-sm font-medium transition-colors duration-200 ${
                      isActive
                        ? 'text-primary-600 bg-primary-50'
                        : 'text-legal-600 hover:text-primary-600 hover:bg-legal-100'
                    }`}
                  >
                    <Icon className="h-4 w-4 mr-2" />
                    {item.name}
                  </Link>
                );
              })}
            </nav>

            {/* User Menu */}
            <div className="hidden md:flex items-center space-x-4">
              <div className="relative">
                <button
                  onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
                  className="flex items-center space-x-2 text-legal-600 hover:text-legal-900 p-2 rounded-lg hover:bg-legal-100 transition-colors duration-200"
                >
                  <div className="w-8 h-8 bg-primary-100 rounded-full flex items-center justify-center">
                    <User className="h-4 w-4 text-primary-600" />
                  </div>
                  <span className="text-sm font-medium">{user.name || 'Utilisateur'}</span>
                </button>

                {/* User Dropdown */}
                {isUserMenuOpen && (
                  <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg border border-legal-200 py-2">
                    <div className="px-4 py-2 border-b border-legal-200">
                      <p className="text-sm font-medium text-legal-900">{user.name}</p>
                      <p className="text-xs text-legal-600">{user.email}</p>
                      {user.cabinet && (
                        <p className="text-xs text-legal-500">{user.cabinet}</p>
                      )}
                    </div>
                    <button
                      onClick={handleLogout}
                      className="w-full text-left px-4 py-2 text-sm text-legal-700 hover:bg-legal-50 flex items-center"
                    >
                      <LogOut className="h-4 w-4 mr-2" />
                      Déconnexion
                    </button>
                  </div>
                )}
              </div>
            </div>

            {/* Mobile menu button */}
            <div className="md:hidden">
              <button
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                className="text-legal-600 hover:text-legal-900 p-2"
              >
                {isMobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMobileMenuOpen && (
          <div className="md:hidden border-t border-legal-200 bg-white">
            <div className="px-2 pt-2 pb-3 space-y-1">
              {navigation.map((item) => {
                const Icon = item.icon;
                const isActive = location.pathname === item.href;
                return (
                  <Link
                    key={item.name}
                    to={item.href}
                    onClick={() => setIsMobileMenuOpen(false)}
                    className={`flex items-center px-3 py-2 rounded-md text-base font-medium transition-colors duration-200 ${
                      isActive
                        ? 'text-primary-600 bg-primary-50'
                        : 'text-legal-600 hover:text-primary-600 hover:bg-legal-100'
                    }`}
                  >
                    <Icon className="h-5 w-5 mr-3" />
                    {item.name}
                  </Link>
                );
              })}
              
              {/* Mobile User Info */}
              <div className="border-t border-legal-200 pt-4 mt-4">
                <div className="px-3 py-2">
                  <p className="text-sm font-medium text-legal-900">{user.name}</p>
                  <p className="text-xs text-legal-600">{user.email}</p>
                </div>
                <button
                  onClick={handleLogout}
                  className="w-full text-left px-3 py-2 text-sm text-legal-700 hover:bg-legal-50 flex items-center"
                >
                  <LogOut className="h-4 w-4 mr-2" />
                  Déconnexion
                </button>
              </div>
            </div>
          </div>
        )}
      </header>

      {/* Main Content */}
      <main className="flex-1">
        {children}
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-legal-200 mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex justify-between items-center">
            <div className="flex items-center">
              <Scale className="h-5 w-5 text-primary-600" />
              <span className="ml-2 text-sm text-legal-600">© 2025 Juristia. Conforme RGPD.</span>
            </div>
            <div className="text-sm text-legal-500">
              Assistant juridique IA professionnel
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Layout;