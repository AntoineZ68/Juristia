import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { 
  User, 
  MapPin, 
  Briefcase, 
  Scale, 
  Settings, 
  Newspaper, 
  Bookmark, 
  Archive, 
  MessageCircle, 
  Send, 
  Clock, 
  FileText, 
  Calendar, 
  Download,
  ChevronRight,
  Star,
  Eye,
  Edit3,
  Loader2
} from 'lucide-react';
import { askJuridicalQuestion, useAI } from '../services/aiService';
import AIStatus from '../components/AIStatus';

const Dashboard: React.FC = () => {
  const navigate = useNavigate();
  const { loading: aiLoading, error: aiError, callAI } = useAI();
  
  const [user, setUser] = useState(() => {
    const savedUser = localStorage.getItem('juristia_user');
    return savedUser ? JSON.parse(savedUser) : {};
  });

  const [userProfile, setUserProfile] = useState(() => {
    const savedProfile = localStorage.getItem('juristia_profile');
    return savedProfile ? JSON.parse(savedProfile) : {
      firstName: '',
      lastName: '',
      location: '',
      status: '',
      legalDomains: [],
      writingStyle: 'formal'
    };
  });

  const [chatMessage, setChatMessage] = useState('');
  const [chatHistory, setChatHistory] = useState(() => {
    const savedHistory = localStorage.getItem('juristia_chat_history');
    return savedHistory ? JSON.parse(savedHistory) : [];
  });

  const [newsFilter, setNewsFilter] = useState('all');
  const [isEditingProfile, setIsEditingProfile] = useState(false);

  // Sauvegarder le profil utilisateur
  const saveProfile = (newProfile: any) => {
    setUserProfile(newProfile);
    localStorage.setItem('juristia_profile', JSON.stringify(newProfile));
    
    // Mettre à jour aussi les infos utilisateur de base
    const updatedUser = {
      ...user,
      name: `${newProfile.firstName} ${newProfile.lastName}`.trim() || user.name
    };
    setUser(updatedUser);
    localStorage.setItem('juristia_user', JSON.stringify(updatedUser));
  };

  const handleProfileUpdate = (field: string, value: any) => {
    const newProfile = { ...userProfile, [field]: value };
    saveProfile(newProfile);
  };

  const handleChatSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatMessage.trim()) return;

    const newQuestion = {
      id: Date.now(),
      question: chatMessage,
      timestamp: new Date().toLocaleString(),
      context: userProfile.legalDomains.join(', '),
      response: null,
      loading: true
    };

    // Ajouter la question à l'historique immédiatement
    const updatedHistory = [newQuestion, ...chatHistory.slice(0, 4)];
    setChatHistory(updatedHistory);
    localStorage.setItem('juristia_chat_history', JSON.stringify(updatedHistory));
    
    setChatMessage('');

    // Appeler l'IA via Netlify Functions
    const aiResponse = await callAI(async () => {
      return await askJuridicalQuestion(
        chatMessage,
        userProfile,
        { module: 'dashboard', action: 'chat' }
      );
    });

    // Mettre à jour la question avec la réponse
    const finalHistory = updatedHistory.map(item => 
      item.id === newQuestion.id 
        ? { ...item, response: aiResponse, loading: false, error: aiError }
        : item
    );
    
    setChatHistory(finalHistory);
    localStorage.setItem('juristia_chat_history', JSON.stringify(finalHistory));
  };

  const legalDomainOptions = [
    'Droit pénal',
    'Droit civil',
    'Droit des contrats',
    'Droit du travail',
    'Droit commercial',
    'Droit administratif',
    'Droit de la famille',
    'Droit immobilier',
    'Droit fiscal',
    'Droit international'
  ];

  const statusOptions = [
    'Étudiant en droit',
    'Avocat',
    'Juriste d\'entreprise',
    'Notaire',
    'Magistrat',
    'Conseiller juridique',
    'Autre'
  ];

  const writingStyleOptions = [
    { value: 'formal', label: 'Formel et structuré' },
    { value: 'synthetic', label: 'Synthétique et concis' },
    { value: 'detailed', label: 'Détaillé avec références' },
    { value: 'pedagogical', label: 'Pédagogique et explicatif' }
  ];

  // Données simulées pour la veille juridique
  const legalNews = [
    {
      id: 1,
      title: 'Nouvelle jurisprudence en droit du travail : télétravail et accident du travail',
      summary: 'La Cour de cassation précise les conditions de reconnaissance d\'un accident survenu en télétravail comme accident du travail.',
      date: '2025-01-15',
      domain: 'Droit du travail',
      status: 'unread',
      importance: 'high'
    },
    {
      id: 2,
      title: 'Réforme du droit des contrats : nouvelles dispositions sur la force majeure',
      summary: 'Le législateur adapte les règles de force majeure aux enjeux contemporains, notamment climatiques et sanitaires.',
      date: '2025-01-14',
      domain: 'Droit des contrats',
      status: 'important',
      importance: 'medium'
    },
    {
      id: 3,
      title: 'Droit pénal : évolution de la jurisprudence sur le harcèlement numérique',
      summary: 'Les tribunaux durcissent leur approche concernant les infractions commises sur les réseaux sociaux.',
      date: '2025-01-13',
      domain: 'Droit pénal',
      status: 'read',
      importance: 'high'
    }
  ];

  // Données simulées pour l'historique
  const recentActivity = [
    {
      id: 1,
      type: 'document',
      title: 'Assignation en référé - Dossier Martin',
      template: 'Assignation',
      date: '2025-01-15',
      status: 'completed',
      module: 'redaction-acte'
    },
    {
      id: 2,
      type: 'preparation',
      title: 'Consultation Mme Dupont - Divorce',
      template: 'Préparation RDV',
      date: '2025-01-14',
      status: 'completed',
      module: 'preparation-rdv'
    },
    {
      id: 3,
      type: 'export',
      title: 'Export PDF - Conclusions en défense',
      template: 'Export',
      date: '2025-01-13',
      status: 'completed',
      module: 'export'
    },
    {
      id: 4,
      type: 'chat',
      title: 'Question IA : Procédure de comparution immédiate',
      template: 'Assistant IA',
      date: '2025-01-12',
      status: 'completed',
      module: 'chat'
    }
  ];

  const filteredNews = newsFilter === 'all' 
    ? legalNews 
    : legalNews.filter(news => 
        userProfile.legalDomains.length === 0 || 
        userProfile.legalDomains.includes(news.domain)
      );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-fade-in">
      {/* Header */}
      <div className="mb-8">
        <AIStatus className="mb-4" />
        <h1 className="text-3xl font-bold text-legal-900 mb-2">
          Tableau de bord juridique
        </h1>
        <p className="text-legal-600">
          Votre espace de travail personnalisé pour l'assistance juridique IA
        </p>
      </div>

      {/* Section 1: Assistant IA Juridique - EN HAUT */}
      <div className="mb-8 bg-white rounded-xl shadow-sm border border-legal-200 p-6">
        <h2 className="text-xl font-semibold text-legal-900 mb-6 flex items-center">
          <MessageCircle className="h-5 w-5 mr-2" />
          Assistant IA Juridique
          {aiLoading && <Loader2 className="h-4 w-4 ml-2 animate-spin text-primary-600" />}
        </h2>

        <form onSubmit={handleChatSubmit} className="mb-6">
          <div className="flex space-x-3">
            <input
              type="text"
              className="flex-1 px-4 py-3 border border-legal-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
              placeholder="Ex : Quelle est la procédure de comparution immédiate ?"
              value={chatMessage}
              onChange={(e) => setChatMessage(e.target.value)}
              disabled={aiLoading}
            />
            <button
              type="submit"
              disabled={!chatMessage.trim() || aiLoading}
              className={`px-6 py-3 rounded-lg transition-colors duration-200 ${
                chatMessage.trim() && !aiLoading
                  ? 'bg-primary-600 text-white hover:bg-primary-700'
                  : 'bg-legal-300 text-legal-500 cursor-not-allowed'
              }`}
            >
              {aiLoading ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Send className="h-4 w-4" />
              )}
            </button>
          </div>
        </form>

        {/* Affichage des erreurs IA */}
        {aiError && (
          <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg">
            <p className="text-red-700 text-sm">
              <strong>Erreur IA :</strong> {aiError}
            </p>
          </div>
        )}

        {chatHistory.length > 0 && (
          <div>
            <h3 className="text-sm font-medium text-legal-700 mb-3">Dernières questions</h3>
            <div className="space-y-3">
              {chatHistory.map(item => (
                <div key={item.id} className="p-4 bg-legal-50 rounded-lg">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <p className="text-sm text-legal-900 font-medium mb-2">{item.question}</p>
                      
                      {item.loading && (
                        <div className="flex items-center text-primary-600 text-sm">
                          <Loader2 className="h-3 w-3 animate-spin mr-2" />
                          L'IA analyse votre question...
                        </div>
                      )}
                      
                      {item.error && (
                        <div className="text-red-600 text-sm">
                          Erreur : {item.error}
                        </div>
                      )}
                      
                      {item.response && !item.loading && (
                        <div className="mt-2 p-3 bg-white rounded border-l-4 border-primary-500">
                          <p className="text-sm text-legal-800 whitespace-pre-wrap">
                            {item.response}
                          </p>
                        </div>
                      )}
                      
                      <div className="flex items-center space-x-2 mt-2">
                        <span className="text-xs text-legal-500">{item.timestamp}</span>
                        {item.context && (
                          <span className="text-xs text-primary-600">• {item.context}</span>
                        )}
                      </div>
                    </div>
                    <button className="p-1 text-legal-400 hover:text-primary-600 transition-colors duration-200">
                      <ChevronRight className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Section 2: Profil Utilisateur Juridique */}
        <div className="lg:col-span-1">
          <div className="bg-white rounded-xl shadow-sm border border-legal-200 p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold text-legal-900 flex items-center">
                <User className="h-5 w-5 mr-2" />
                Profil Juridique
              </h2>
              <button
                onClick={() => setIsEditingProfile(!isEditingProfile)}
                className="p-2 text-legal-600 hover:text-primary-600 transition-colors duration-200"
              >
                {isEditingProfile ? <Settings className="h-4 w-4" /> : <Edit3 className="h-4 w-4" />}
              </button>
            </div>

            {isEditingProfile ? (
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-3">
                  <input
                    type="text"
                    placeholder="Prénom"
                    className="px-3 py-2 border border-legal-300 rounded-lg text-sm focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                    value={userProfile.firstName}
                    onChange={(e) => handleProfileUpdate('firstName', e.target.value)}
                  />
                  <input
                    type="text"
                    placeholder="Nom"
                    className="px-3 py-2 border border-legal-300 rounded-lg text-sm focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                    value={userProfile.lastName}
                    onChange={(e) => handleProfileUpdate('lastName', e.target.value)}
                  />
                </div>

                <input
                  type="text"
                  placeholder="Localisation (ville, pays)"
                  className="w-full px-3 py-2 border border-legal-300 rounded-lg text-sm focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                  value={userProfile.location}
                  onChange={(e) => handleProfileUpdate('location', e.target.value)}
                />

                <select
                  className="w-full px-3 py-2 border border-legal-300 rounded-lg text-sm focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                  value={userProfile.status}
                  onChange={(e) => handleProfileUpdate('status', e.target.value)}
                >
                  <option value="">Sélectionner votre statut</option>
                  {statusOptions.map(status => (
                    <option key={status} value={status}>{status}</option>
                  ))}
                </select>

                <div>
                  <label className="block text-sm font-medium text-legal-700 mb-2">
                    Domaines juridiques
                  </label>
                  <div className="space-y-2 max-h-32 overflow-y-auto">
                    {legalDomainOptions.map(domain => (
                      <label key={domain} className="flex items-center">
                        <input
                          type="checkbox"
                          className="rounded border-legal-300 text-primary-600 focus:ring-primary-500 mr-2"
                          checked={userProfile.legalDomains.includes(domain)}
                          onChange={(e) => {
                            const newDomains = e.target.checked
                              ? [...userProfile.legalDomains, domain]
                              : userProfile.legalDomains.filter((d: string) => d !== domain);
                            handleProfileUpdate('legalDomains', newDomains);
                          }}
                        />
                        <span className="text-sm text-legal-700">{domain}</span>
                      </label>
                    ))}
                  </div>
                </div>

                <select
                  className="w-full px-3 py-2 border border-legal-300 rounded-lg text-sm focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                  value={userProfile.writingStyle}
                  onChange={(e) => handleProfileUpdate('writingStyle', e.target.value)}
                >
                  {writingStyleOptions.map(style => (
                    <option key={style.value} value={style.value}>{style.label}</option>
                  ))}
                </select>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="flex items-center text-legal-700">
                  <User className="h-4 w-4 mr-2 text-legal-500" />
                  <span className="font-medium">
                    {userProfile.firstName || userProfile.lastName 
                      ? `${userProfile.firstName} ${userProfile.lastName}`.trim()
                      : user.name || 'Nom non renseigné'
                    }
                  </span>
                </div>

                {userProfile.location && (
                  <div className="flex items-center text-legal-600">
                    <MapPin className="h-4 w-4 mr-2 text-legal-500" />
                    <span className="text-sm">{userProfile.location}</span>
                  </div>
                )}

                {userProfile.status && (
                  <div className="flex items-center text-legal-600">
                    <Briefcase className="h-4 w-4 mr-2 text-legal-500" />
                    <span className="text-sm">{userProfile.status}</span>
                  </div>
                )}

                {userProfile.legalDomains.length > 0 && (
                  <div>
                    <div className="flex items-center text-legal-600 mb-2">
                      <Scale className="h-4 w-4 mr-2 text-legal-500" />
                      <span className="text-sm font-medium">Domaines d'expertise</span>
                    </div>
                    <div className="flex flex-wrap gap-1">
                      {userProfile.legalDomains.slice(0, 3).map((domain: string) => (
                        <span key={domain} className="px-2 py-1 bg-primary-100 text-primary-700 text-xs rounded-full">
                          {domain}
                        </span>
                      ))}
                      {userProfile.legalDomains.length > 3 && (
                        <span className="px-2 py-1 bg-legal-100 text-legal-600 text-xs rounded-full">
                          +{userProfile.legalDomains.length - 3}
                        </span>
                      )}
                    </div>
                  </div>
                )}

                {!userProfile.firstName && !userProfile.status && (
                  <div className="text-center py-4">
                    <p className="text-legal-500 text-sm mb-2">Complétez votre profil</p>
                    <button
                      onClick={() => setIsEditingProfile(true)}
                      className="text-primary-600 hover:text-primary-700 text-sm font-medium"
                    >
                      Renseigner mes informations
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Section 3: Historique des demandes - AVANT Veille Juridique */}
        <div className="lg:col-span-2">
          <div className="bg-white rounded-xl shadow-sm border border-legal-200 p-6 mb-8">
            <h2 className="text-xl font-semibold text-legal-900 mb-6 flex items-center">
              <Clock className="h-5 w-5 mr-2" />
              Historique des demandes
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {recentActivity.map(activity => (
                <div key={activity.id} className="border border-legal-200 rounded-lg p-4 hover:shadow-md transition-all duration-200 cursor-pointer group">
                  <div className="flex items-center justify-between mb-3">
                    <div className={`p-2 rounded-lg ${
                      activity.type === 'document' ? 'bg-purple-100' :
                      activity.type === 'preparation' ? 'bg-blue-100' :
                      activity.type === 'export' ? 'bg-green-100' : 'bg-orange-100'
                    }`}>
                      {activity.type === 'document' && <FileText className="h-4 w-4 text-purple-600" />}
                      {activity.type === 'preparation' && <Calendar className="h-4 w-4 text-blue-600" />}
                      {activity.type === 'export' && <Download className="h-4 w-4 text-green-600" />}
                      {activity.type === 'chat' && <MessageCircle className="h-4 w-4 text-orange-600" />}
                    </div>
                    <span className={`w-2 h-2 rounded-full ${
                      activity.status === 'completed' ? 'bg-green-500' : 'bg-yellow-500'
                    }`}></span>
                  </div>

                  <h3 className="font-medium text-legal-900 mb-2 text-sm leading-tight group-hover:text-primary-600 transition-colors duration-200">
                    {activity.title}
                  </h3>

                  <div className="flex items-center justify-between">
                    <span className="text-xs text-legal-500">{activity.date}</span>
                    <div className="flex space-x-1">
                      <button 
                        onClick={() => navigate(`/${activity.module}`)}
                        className="p-1 text-legal-400 hover:text-primary-600 transition-colors duration-200"
                      >
                        <Eye className="h-3 w-3" />
                      </button>
                      <button className="p-1 text-legal-400 hover:text-primary-600 transition-colors duration-200">
                        <Edit3 className="h-3 w-3" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-6 text-center">
              <button className="text-sm text-primary-600 hover:text-primary-700 font-medium transition-colors duration-200">
                Voir tout l'historique →
              </button>
            </div>
          </div>

          {/* Section 4: Veille Juridique - APRÈS Historique */}
          <div className="bg-white rounded-xl shadow-sm border border-legal-200 p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold text-legal-900 flex items-center">
                <Newspaper className="h-5 w-5 mr-2" />
                Veille Juridique
              </h2>
              <div className="flex space-x-2">
                <button
                  onClick={() => setNewsFilter('all')}
                  className={`px-3 py-1 text-xs rounded-full transition-colors duration-200 ${
                    newsFilter === 'all' 
                      ? 'bg-primary-100 text-primary-700' 
                      : 'bg-legal-100 text-legal-600 hover:bg-legal-200'
                  }`}
                >
                  Toutes
                </button>
                <button
                  onClick={() => setNewsFilter('personalized')}
                  className={`px-3 py-1 text-xs rounded-full transition-colors duration-200 ${
                    newsFilter === 'personalized' 
                      ? 'bg-primary-100 text-primary-700' 
                      : 'bg-legal-100 text-legal-600 hover:bg-legal-200'
                  }`}
                >
                  Personnalisées
                </button>
              </div>
            </div>

            <div className="space-y-4">
              {filteredNews.map(news => (
                <div key={news.id} className="border border-legal-200 rounded-lg p-4 hover:bg-legal-50 transition-colors duration-200">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-2">
                        <span className={`px-2 py-1 text-xs rounded-full ${
                          news.importance === 'high' 
                            ? 'bg-red-100 text-red-700' 
                            : 'bg-blue-100 text-blue-700'
                        }`}>
                          {news.domain}
                        </span>
                        <span className="text-xs text-legal-500">{news.date}</span>
                      </div>
                      <h3 className="font-medium text-legal-900 mb-2 leading-tight">
                        {news.title}
                      </h3>
                      <p className="text-sm text-legal-600 leading-relaxed">
                        {news.summary}
                      </p>
                    </div>
                    <div className="flex space-x-1 ml-4">
                      <button className="p-1 text-legal-400 hover:text-primary-600 transition-colors duration-200">
                        <Bookmark className="h-4 w-4" />
                      </button>
                      <button className="p-1 text-legal-400 hover:text-legal-600 transition-colors duration-200">
                        <Archive className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;