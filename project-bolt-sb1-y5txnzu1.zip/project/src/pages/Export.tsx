import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Download, FileText, Image, Settings, CheckCircle, Eye, ArrowLeft, Calendar, Plus, Loader2 } from 'lucide-react';
import { useMakeIntegration } from '../hooks/useMakeIntegration';

const Export: React.FC = () => {
  const navigate = useNavigate();
  const [selectedFormat, setSelectedFormat] = useState('pdf');
  const [selectedTemplate, setSelectedTemplate] = useState('professional');
  const [selectedDocument, setSelectedDocument] = useState<number | null>(null);
  const { loading, error, exportDoc } = useMakeIntegration();

  const formats = [
    { id: 'pdf', name: 'PDF', description: 'Format professionnel non-éditable', icon: FileText },
    { id: 'word', name: 'Word', description: 'Format éditable (.docx)', icon: FileText },
  ];

  const templates = [
    {
      id: 'professional',
      name: 'Professionnel',
      description: 'Design classique pour les tribunaux',
      preview: 'bg-gradient-to-br from-legal-100 to-legal-200',
    },
    {
      id: 'modern',
      name: 'Moderne',
      description: 'Design contemporain avec accents colorés',
      preview: 'bg-gradient-to-br from-primary-100 to-primary-200',
    },
    {
      id: 'minimal',
      name: 'Minimaliste',
      description: 'Design épuré et lisible',
      preview: 'bg-gradient-to-br from-gray-100 to-gray-200',
    },
  ];

  const documents = [
    {
      id: 1,
      title: 'Assignation en référé - Dossier Martin',
      type: 'Assignation',
      date: '2025-01-15',
      status: 'ready',
      module: 'redaction-acte'
    },
    {
      id: 2,
      title: 'Conclusions en défense - Affaire Dupont',
      type: 'Conclusions',
      date: '2025-01-14',
      status: 'ready',
      module: 'redaction-acte'
    },
    {
      id: 3,
      title: 'Résumé consultation - Client Bernard',
      type: 'Consultation',
      date: '2025-01-13',
      status: 'ready',
      module: 'preparation-rdv'
    },
  ];

  const recentExports = [
    { name: 'Assignation_Martin_2025.pdf', date: 'Il y a 2h', size: '245 KB' },
    { name: 'Conclusions_Dupont_2025.docx', date: 'Il y a 1j', size: '189 KB' },
    { name: 'Consultation_Bernard_2025.pdf', date: 'Il y a 2j', size: '156 KB' },
  ];

  const handleExport = async () => {
    if (selectedDocument) {
      const document = documents.find(d => d.id === selectedDocument);
      if (document) {
        const result = await exportDoc(
          {
            title: document.title,
            type: document.type,
            content: 'Document content here...' // En production, récupérer le vrai contenu
          },
          selectedFormat,
          selectedTemplate
        );
        
        if (result) {
          // Simuler le téléchargement
          const fileName = `${document.title.replace(/\s+/g, '_')}.${selectedFormat}`;
          alert(`Export réussi ! Le fichier "${fileName}" sera téléchargé via Make.com`);
        }
      }
    } else {
      alert('Veuillez sélectionner un document à exporter');
    }
  };

  const handleCreateNew = (module: string) => {
    navigate(`/${module}`);
  };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-fade-in">
      {/* Header with breadcrumb */}
      <div className="mb-8">
        <nav className="flex items-center space-x-2 text-sm text-legal-600 mb-4">
          <Link to="/" className="hover:text-primary-600 transition-colors duration-200">Dashboard</Link>
          <span>/</span>
          <span className="text-legal-900 font-medium">Export</span>
        </nav>
        <h1 className="text-3xl font-bold text-legal-900 mb-2">
          Export professionnel
        </h1>
        <p className="text-legal-600">
          Exportez vos documents avec un design juridique professionnel via Make.com
        </p>
      </div>

      {/* Loading State */}
      {loading && (
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-6 mb-6">
          <div className="flex items-center">
            <Loader2 className="h-6 w-6 text-blue-600 animate-spin mr-3" />
            <div>
              <h3 className="text-lg font-medium text-blue-900">
                Export en cours...
              </h3>
              <p className="text-blue-700">
                Génération du document via Make.com
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Error State */}
      {error && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-6 mb-6">
          <div className="flex items-center">
            <div className="text-red-600 mr-3">⚠️</div>
            <div>
              <h3 className="text-lg font-medium text-red-900">
                Erreur d'export
              </h3>
              <p className="text-red-700">{error}</p>
            </div>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Documents List */}
        <div className="lg:col-span-2">
          <div className="bg-white rounded-xl shadow-sm border border-legal-200 p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold text-legal-900">
                Documents disponibles
              </h2>
              <div className="flex space-x-2">
                <button
                  onClick={() => handleCreateNew('preparation-rdv')}
                  className="inline-flex items-center px-3 py-2 text-sm bg-blue-100 text-blue-700 rounded-lg hover:bg-blue-200 transition-colors duration-200"
                >
                  <Calendar className="h-4 w-4 mr-1" />
                  Nouveau RDV
                </button>
                <button
                  onClick={() => handleCreateNew('redaction-acte')}
                  className="inline-flex items-center px-3 py-2 text-sm bg-purple-100 text-purple-700 rounded-lg hover:bg-purple-200 transition-colors duration-200"
                >
                  <FileText className="h-4 w-4 mr-1" />
                  Nouvel acte
                </button>
              </div>
            </div>

            {documents.length === 0 ? (
              <div className="text-center py-12">
                <FileText className="h-12 w-12 text-legal-300 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-legal-900 mb-2">Aucun document disponible</h3>
                <p className="text-legal-600 mb-6">Créez votre premier document pour commencer</p>
                <div className="flex justify-center space-x-4">
                  <button
                    onClick={() => handleCreateNew('preparation-rdv')}
                    className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors duration-200"
                  >
                    <Calendar className="h-4 w-4 mr-2" />
                    Préparer un RDV
                  </button>
                  <button
                    onClick={() => handleCreateNew('redaction-acte')}
                    className="inline-flex items-center px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors duration-200"
                  >
                    <FileText className="h-4 w-4 mr-2" />
                    Rédiger un acte
                  </button>
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                {documents.map((doc) => (
                  <div
                    key={doc.id}
                    onClick={() => setSelectedDocument(doc.id)}
                    className={`flex items-center justify-between p-4 border-2 rounded-lg cursor-pointer transition-all duration-200 ${
                      selectedDocument === doc.id
                        ? 'border-primary-500 bg-primary-50'
                        : 'border-legal-200 hover:border-primary-300 hover:bg-legal-50'
                    }`}
                  >
                    <div className="flex items-center">
                      <div className={`p-2 rounded-lg mr-4 ${
                        doc.type === 'Assignation' ? 'bg-purple-100' :
                        doc.type === 'Conclusions' ? 'bg-blue-100' : 'bg-green-100'
                      }`}>
                        <FileText className={`h-5 w-5 ${
                          doc.type === 'Assignation' ? 'text-purple-600' :
                          doc.type === 'Conclusions' ? 'text-blue-600' : 'text-green-600'
                        }`} />
                      </div>
                      <div>
                        <h3 className="font-medium text-legal-900">{doc.title}</h3>
                        <div className="flex items-center space-x-4 mt-1">
                          <span className="text-sm text-legal-600">{doc.type}</span>
                          <span className="text-sm text-legal-500">{doc.date}</span>
                          <div className="flex items-center">
                            <CheckCircle className="h-4 w-4 text-green-500 mr-1" />
                            <span className="text-sm text-green-600">Prêt</span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <button 
                        onClick={(e) => {
                          e.stopPropagation();
                          navigate(`/${doc.module}`);
                        }}
                        className="p-2 text-legal-600 hover:text-primary-600 transition-colors duration-200"
                      >
                        <Eye className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Export Settings */}
        <div className="space-y-6">
          {/* Format Selection */}
          <div className="bg-white rounded-xl shadow-sm border border-legal-200 p-6">
            <h3 className="text-lg font-semibold text-legal-900 mb-4 flex items-center">
              <Settings className="h-5 w-5 mr-2" />
              Format d'export
            </h3>

            <div className="space-y-3">
              {formats.map((format) => {
                const Icon = format.icon;
                return (
                  <div
                    key={format.id}
                    onClick={() => setSelectedFormat(format.id)}
                    className={`p-4 border-2 rounded-lg cursor-pointer transition-all duration-200 ${
                      selectedFormat === format.id
                        ? 'border-primary-500 bg-primary-50'
                        : 'border-legal-200 hover:border-primary-300'
                    }`}
                  >
                    <div className="flex items-center">
                      <Icon className={`h-5 w-5 mr-3 ${
                        selectedFormat === format.id ? 'text-primary-600' : 'text-legal-400'
                      }`} />
                      <div>
                        <h4 className="font-medium text-legal-900">{format.name}</h4>
                        <p className="text-sm text-legal-600">{format.description}</p>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Template Selection */}
          <div className="bg-white rounded-xl shadow-sm border border-legal-200 p-6">
            <h3 className="text-lg font-semibold text-legal-900 mb-4 flex items-center">
              <Image className="h-5 w-5 mr-2" />
              Modèle de design
            </h3>

            <div className="space-y-3">
              {templates.map((template) => (
                <div
                  key={template.id}
                  onClick={() => setSelectedTemplate(template.id)}
                  className={`p-4 border-2 rounded-lg cursor-pointer transition-all duration-200 ${
                    selectedTemplate === template.id
                      ? 'border-primary-500 bg-primary-50'
                      : 'border-legal-200 hover:border-primary-300'
                  }`}
                >
                  <div className="flex items-center">
                    <div className={`w-12 h-8 rounded mr-3 ${template.preview}`}></div>
                    <div>
                      <h4 className="font-medium text-legal-900">{template.name}</h4>
                      <p className="text-sm text-legal-600">{template.description}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Export Options */}
          <div className="bg-white rounded-xl shadow-sm border border-legal-200 p-6">
            <h3 className="text-lg font-semibold text-legal-900 mb-4">
              Options avancées
            </h3>

            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <label className="text-sm font-medium text-legal-700">
                  Inclure l'en-tête cabinet
                </label>
                <input
                  type="checkbox"
                  defaultChecked
                  className="rounded border-legal-300 text-primary-600 focus:ring-primary-500"
                />
              </div>

              <div className="flex items-center justify-between">
                <label className="text-sm font-medium text-legal-700">
                  Numérotation des pages
                </label>
                <input
                  type="checkbox"
                  defaultChecked
                  className="rounded border-legal-300 text-primary-600 focus:ring-primary-500"
                />
              </div>

              <div className="flex items-center justify-between">
                <label className="text-sm font-medium text-legal-700">
                  Filigrane "CONFIDENTIEL"
                </label>
                <input
                  type="checkbox"
                  className="rounded border-legal-300 text-primary-600 focus:ring-primary-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-legal-700 mb-2">
                  Qualité d'export
                </label>
                <select className="w-full px-3 py-2 border border-legal-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500">
                  <option>Haute qualité (recommandé)</option>
                  <option>Qualité standard</option>
                  <option>Optimisé pour email</option>
                </select>
              </div>
            </div>
          </div>

          {/* Export Button */}
          <div className="flex space-x-3">
            <Link
              to="/"
              className="flex-1 inline-flex items-center justify-center px-6 py-3 border border-legal-300 text-legal-700 rounded-lg hover:bg-legal-50 transition-colors duration-200"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Retour
            </Link>
            <button 
              onClick={handleExport}
              disabled={loading || !selectedDocument}
              className={`flex-1 inline-flex items-center justify-center px-6 py-3 rounded-lg transition-colors duration-200 ${
                selectedDocument && !loading
                  ? 'bg-primary-600 text-white hover:bg-primary-700'
                  : 'bg-legal-300 text-legal-500 cursor-not-allowed'
              }`}
            >
              {loading ? (
                <>
                  <Loader2 className="animate-spin h-5 w-5 mr-2" />
                  Export...
                </>
              ) : (
                <>
                  <Download className="h-5 w-5 mr-2" />
                  Exporter
                </>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Recent Exports */}
      {recentExports.length > 0 && (
        <div className="mt-12 bg-white rounded-xl shadow-sm border border-legal-200 p-6">
          <h2 className="text-xl font-semibold text-legal-900 mb-6">
            Exports récents
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {recentExports.map((file, index) => (
              <div
                key={index}
                className="flex items-center justify-between p-4 bg-legal-50 rounded-lg hover:bg-legal-100 transition-colors duration-200 cursor-pointer group"
              >
                <div className="flex items-center">
                  <FileText className="h-5 w-5 text-primary-600 mr-3" />
                  <div>
                    <p className="font-medium text-legal-900 text-sm">{file.name}</p>
                    <p className="text-xs text-legal-600">{file.date} • {file.size}</p>
                  </div>
                </div>
                <button className="p-1 text-legal-600 hover:text-primary-600 transition-colors duration-200 opacity-0 group-hover:opacity-100">
                  <Download className="h-4 w-4" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default Export;