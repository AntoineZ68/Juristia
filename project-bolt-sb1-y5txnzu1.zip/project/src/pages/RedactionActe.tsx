import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { 
  FileText, 
  ArrowRight, 
  CheckCircle, 
  ArrowLeft, 
  Download, 
  Eye, 
  Loader2,
  Scale,
  Users,
  Heart,
  Briefcase,
  Plus,
  Search,
  Filter,
  Copy,
  Edit3,
  Trash2,
  Calendar
} from 'lucide-react';
import { useMakeIntegration } from '../hooks/useMakeIntegration';

const RedactionActe: React.FC = () => {
  const navigate = useNavigate();
  const [currentStep, setCurrentStep] = useState(1);
  const [selectedCategory, setSelectedCategory] = useState('');
  const [selectedTemplate, setSelectedTemplate] = useState('');
  const [generatedDocument, setGeneratedDocument] = useState<string>('');
  const [searchTerm, setSearchTerm] = useState('');
  const { loading, error, generateDocument } = useMakeIntegration();
  
  // Récupérer le profil utilisateur pour la personnalisation
  const [userProfile, setUserProfile] = useState(() => {
    const savedProfile = localStorage.getItem('juristia_profile');
    return savedProfile ? JSON.parse(savedProfile) : {
      legalDomains: [],
      writingStyle: 'formal',
      status: ''
    };
  });

  const [formData, setFormData] = useState({
    demandeur: '',
    defendeur: '',
    tribunal: '',
    urgence: '',
    objet: '',
    faits: '',
    montant: '',
    dateEcheance: '',
    client: ''
  });

  // Historique des rédactions
  const [documentHistory, setDocumentHistory] = useState(() => {
    const savedHistory = localStorage.getItem('juristia_document_history');
    return savedHistory ? JSON.parse(savedHistory) : [];
  });

  // Catégories d'actes juridiques
  const categories = [
    {
      id: 'penal',
      title: 'Droit pénal',
      icon: Scale,
      color: 'bg-red-100 text-red-700',
      description: 'Plaintes, mémoires, réquisitoires...'
    },
    {
      id: 'civil',
      title: 'Droit civil',
      icon: FileText,
      color: 'bg-blue-100 text-blue-700',
      description: 'Assignations, sommations, conclusions...'
    },
    {
      id: 'famille',
      title: 'Droit de la famille',
      icon: Heart,
      color: 'bg-pink-100 text-pink-700',
      description: 'Divorce, garde d\'enfants, conventions...'
    },
    {
      id: 'contrats',
      title: 'Droit des contrats',
      icon: Briefcase,
      color: 'bg-green-100 text-green-700',
      description: 'Contrats, baux, ruptures...'
    },
    {
      id: 'travail',
      title: 'Droit du travail',
      icon: Users,
      color: 'bg-purple-100 text-purple-700',
      description: 'Licenciements, prud\'hommes, conventions...'
    }
  ];

  // Templates par catégorie
  const templates = {
    penal: [
      {
        id: 'plainte-simple',
        title: 'Plainte simple',
        description: 'Dépôt de plainte pour infraction pénale',
        complexity: 'simple',
        fields: ['demandeur', 'faits', 'prejudice']
      },
      {
        id: 'constitution-partie-civile',
        title: 'Constitution de partie civile',
        description: 'Se constituer partie civile dans une procédure pénale',
        complexity: 'medium',
        fields: ['demandeur', 'defendeur', 'faits', 'prejudice', 'montant']
      },
      {
        id: 'memoire-defense-penal',
        title: 'Mémoire en défense pénale',
        description: 'Défense dans une procédure pénale',
        complexity: 'complex',
        fields: ['defendeur', 'faits', 'moyens-defense', 'jurisprudence']
      }
    ],
    civil: [
      {
        id: 'assignation-refere',
        title: 'Assignation en référé',
        description: 'Procédure d\'urgence devant le tribunal',
        complexity: 'complex',
        fields: ['demandeur', 'defendeur', 'tribunal', 'urgence', 'objet', 'faits']
      },
      {
        id: 'sommation-payer',
        title: 'Sommation de payer',
        description: 'Mise en demeure de paiement',
        complexity: 'simple',
        fields: ['demandeur', 'defendeur', 'montant', 'dateEcheance']
      },
      {
        id: 'conclusions-defense',
        title: 'Conclusions en défense',
        description: 'Réponse aux demandes adverses',
        complexity: 'complex',
        fields: ['defendeur', 'demandeur', 'faits', 'moyens-defense']
      }
    ],
    famille: [
      {
        id: 'requete-divorce',
        title: 'Requête en divorce',
        description: 'Demande de divorce par consentement mutuel',
        complexity: 'medium',
        fields: ['epoux1', 'epoux2', 'motifs', 'enfants', 'biens']
      },
      {
        id: 'convention-parentale',
        title: 'Convention parentale',
        description: 'Accord sur l\'exercice de l\'autorité parentale',
        complexity: 'medium',
        fields: ['parent1', 'parent2', 'enfants', 'garde', 'pension']
      }
    ],
    contrats: [
      {
        id: 'contrat-vente',
        title: 'Contrat de vente',
        description: 'Accord de vente entre parties',
        complexity: 'medium',
        fields: ['vendeur', 'acheteur', 'objet', 'prix', 'conditions']
      },
      {
        id: 'bail-habitation',
        title: 'Bail d\'habitation',
        description: 'Contrat de location d\'un logement',
        complexity: 'medium',
        fields: ['bailleur', 'locataire', 'logement', 'loyer', 'duree']
      },
      {
        id: 'rupture-contrat',
        title: 'Lettre de rupture de contrat',
        description: 'Notification de rupture contractuelle',
        complexity: 'simple',
        fields: ['expediteur', 'destinataire', 'contrat', 'motifs']
      }
    ],
    travail: [
      {
        id: 'lettre-licenciement',
        title: 'Lettre de licenciement',
        description: 'Notification de licenciement',
        complexity: 'complex',
        fields: ['employeur', 'salarie', 'motifs', 'procedure', 'indemnites']
      },
      {
        id: 'saisine-prudhommes',
        title: 'Saisine du conseil de prud\'hommes',
        description: 'Demande devant les prud\'hommes',
        complexity: 'complex',
        fields: ['demandeur', 'defendeur', 'litige', 'demandes']
      }
    ]
  };

  const handleGenerate = async () => {
    const template = templates[selectedCategory as keyof typeof templates]?.find(t => t.id === selectedTemplate);
    if (!template) return;

    const result = await generateDocument({
      ...formData,
      userProfile,
      templateType: selectedTemplate,
      category: selectedCategory
    }, selectedTemplate);
    
    if (result) {
      setGeneratedDocument(result.document || result.content);
      
      // Sauvegarder dans l'historique
      const newDocument = {
        id: Date.now(),
        title: template.title,
        category: selectedCategory,
        template: selectedTemplate,
        date: new Date().toISOString().split('T')[0],
        status: 'completed',
        content: result.document || result.content,
        formData: { ...formData }
      };
      
      const updatedHistory = [newDocument, ...documentHistory.slice(0, 9)];
      setDocumentHistory(updatedHistory);
      localStorage.setItem('juristia_document_history', JSON.stringify(updatedHistory));
      
      setCurrentStep(3);
    }
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const resetForm = () => {
    setCurrentStep(1);
    setSelectedCategory('');
    setSelectedTemplate('');
    setFormData({
      demandeur: '',
      defendeur: '',
      tribunal: '',
      urgence: '',
      objet: '',
      faits: '',
      montant: '',
      dateEcheance: '',
      client: ''
    });
    setGeneratedDocument('');
  };

  const duplicateDocument = (doc: any) => {
    setFormData(doc.formData);
    setSelectedCategory(doc.category);
    setSelectedTemplate(doc.template);
    setCurrentStep(2);
  };

  const deleteDocument = (docId: number) => {
    const updatedHistory = documentHistory.filter((doc: any) => doc.id !== docId);
    setDocumentHistory(updatedHistory);
    localStorage.setItem('juristia_document_history', JSON.stringify(updatedHistory));
  };

  // Filtrer les templates selon les domaines de l'utilisateur
  const getRecommendedCategories = () => {
    if (userProfile.legalDomains.length === 0) return categories;
    
    const domainMapping: { [key: string]: string[] } = {
      'Droit pénal': ['penal'],
      'Droit civil': ['civil'],
      'Droit de la famille': ['famille'],
      'Droit des contrats': ['contrats'],
      'Droit du travail': ['travail']
    };
    
    const recommendedIds = userProfile.legalDomains.flatMap((domain: string) => 
      domainMapping[domain] || []
    );
    
    return categories.filter(cat => recommendedIds.includes(cat.id));
  };

  const filteredTemplates = selectedCategory && templates[selectedCategory as keyof typeof templates] 
    ? templates[selectedCategory as keyof typeof templates].filter(template =>
        searchTerm === '' || 
        template.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        template.description.toLowerCase().includes(searchTerm.toLowerCase())
      )
    : [];

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-fade-in">
      {/* Header */}
      <div className="mb-8">
        <nav className="flex items-center space-x-2 text-sm text-legal-600 mb-4">
          <Link to="/dashboard" className="hover:text-primary-600 transition-colors duration-200">Dashboard</Link>
          <span>/</span>
          <span className="text-legal-900 font-medium">Rédaction d'acte</span>
        </nav>
        <h1 className="text-3xl font-bold text-legal-900 mb-2">
          Rédacteur d'actes juridiques
        </h1>
        <p className="text-legal-600">
          Créez des documents juridiques personnalisés selon votre profil et expertise
        </p>
      </div>

      {/* Progress Steps */}
      <div className="mb-8">
        <div className="flex items-center justify-center space-x-8">
          {[
            { id: 1, title: 'Choix du type', icon: FileText },
            { id: 2, title: 'Formulaire', icon: Edit3 },
            { id: 3, title: 'Résultat', icon: CheckCircle }
          ].map((step, index) => {
            const Icon = step.icon;
            return (
              <div key={step.id} className="flex items-center">
                <div className={`flex items-center justify-center w-10 h-10 rounded-full border-2 transition-all duration-300 ${
                  currentStep >= step.id 
                    ? 'bg-primary-600 border-primary-600 text-white' 
                    : 'border-legal-300 text-legal-400'
                }`}>
                  <Icon className="h-5 w-5" />
                </div>
                <span className={`ml-2 text-sm font-medium ${
                  currentStep >= step.id ? 'text-legal-900' : 'text-legal-500'
                }`}>
                  {step.title}
                </span>
                {index < 2 && (
                  <div className={`mx-4 h-0.5 w-16 transition-all duration-300 ${
                    currentStep > step.id ? 'bg-primary-600' : 'bg-legal-300'
                  }`} />
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Loading State */}
      {loading && (
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-6 mb-6">
          <div className="flex items-center">
            <Loader2 className="h-6 w-6 text-blue-600 animate-spin mr-3" />
            <div>
              <h3 className="text-lg font-medium text-blue-900">
                Génération en cours...
              </h3>
              <p className="text-blue-700">
                L'IA rédige votre document personnalisé via Make.com
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Error State */}
      {error && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-6 mb-6">
          <div className="flex items-center">
            <div className="text-red-600 mr-3">⚠️</div>
            <div>
              <h3 className="text-lg font-medium text-red-900">
                Erreur de génération
              </h3>
              <p className="text-red-700">{error}</p>
            </div>
          </div>
        </div>
      )}

      {/* Step 1: Choix du type d'acte */}
      {currentStep === 1 && (
        <div className="space-y-8">
          {/* Catégories recommandées */}
          {userProfile.legalDomains.length > 0 && (
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
              <h3 className="text-lg font-medium text-blue-900 mb-4">
                📋 Recommandé selon votre profil
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {getRecommendedCategories().map((category) => {
                  const Icon = category.icon;
                  return (
                    <button
                      key={category.id}
                      onClick={() => {
                        setSelectedCategory(category.id);
                        setCurrentStep(1.5);
                      }}
                      className="p-4 border-2 border-blue-300 rounded-lg hover:border-primary-500 hover:bg-white transition-all duration-200 text-left group"
                    >
                      <div className="flex items-center mb-3">
                        <div className={`p-2 rounded-lg ${category.color} mr-3`}>
                          <Icon className="h-5 w-5" />
                        </div>
                        <h4 className="font-semibold text-legal-900 group-hover:text-primary-600">
                          {category.title}
                        </h4>
                      </div>
                      <p className="text-sm text-legal-600">
                        {category.description}
                      </p>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Toutes les catégories */}
          <div className="bg-white rounded-xl shadow-sm border border-legal-200 p-8">
            <h2 className="text-xl font-semibold text-legal-900 mb-6">
              Choisissez une catégorie d'acte
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {categories.map((category) => {
                const Icon = category.icon;
                return (
                  <button
                    key={category.id}
                    onClick={() => {
                      setSelectedCategory(category.id);
                      setCurrentStep(1.5);
                    }}
                    className="p-6 border-2 border-legal-200 rounded-lg hover:border-primary-500 hover:shadow-md transition-all duration-200 text-left group"
                  >
                    <div className="flex items-center mb-4">
                      <div className={`p-3 rounded-lg ${category.color} mr-4`}>
                        <Icon className="h-6 w-6" />
                      </div>
                      <h3 className="font-semibold text-legal-900 group-hover:text-primary-600">
                        {category.title}
                      </h3>
                    </div>
                    <p className="text-legal-600 text-sm">
                      {category.description}
                    </p>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Historique des rédactions */}
          {documentHistory.length > 0 && (
            <div className="bg-white rounded-xl shadow-sm border border-legal-200 p-8">
              <h2 className="text-xl font-semibold text-legal-900 mb-6">
                Historique des rédactions
              </h2>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {documentHistory.slice(0, 6).map((doc: any) => (
                  <div key={doc.id} className="border border-legal-200 rounded-lg p-4 hover:shadow-md transition-all duration-200">
                    <div className="flex items-center justify-between mb-3">
                      <span className="px-2 py-1 bg-legal-100 text-legal-700 text-xs rounded-full">
                        {categories.find(c => c.id === doc.category)?.title}
                      </span>
                      <div className="flex space-x-1">
                        <button
                          onClick={() => duplicateDocument(doc)}
                          className="p-1 text-legal-400 hover:text-primary-600 transition-colors duration-200"
                          title="Dupliquer"
                        >
                          <Copy className="h-3 w-3" />
                        </button>
                        <button
                          onClick={() => deleteDocument(doc.id)}
                          className="p-1 text-legal-400 hover:text-red-600 transition-colors duration-200"
                          title="Supprimer"
                        >
                          <Trash2 className="h-3 w-3" />
                        </button>
                      </div>
                    </div>
                    <h3 className="font-medium text-legal-900 mb-2 text-sm">
                      {doc.title}
                    </h3>
                    <div className="flex items-center justify-between text-xs text-legal-500">
                      <span>{doc.date}</span>
                      <span className="flex items-center">
                        <CheckCircle className="h-3 w-3 text-green-500 mr-1" />
                        Terminé
                      </span>
                    </div>
                  </div>
                ))}
              </div>

              {documentHistory.length > 6 && (
                <div className="mt-6 text-center">
                  <button className="text-sm text-primary-600 hover:text-primary-700 font-medium">
                    Voir tout l'historique ({documentHistory.length} documents) →
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* Step 1.5: Choix du template */}
      {currentStep === 1.5 && selectedCategory && (
        <div className="bg-white rounded-xl shadow-sm border border-legal-200 p-8">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-semibold text-legal-900">
              {categories.find(c => c.id === selectedCategory)?.title} - Choisissez un modèle
            </h2>
            <div className="flex items-center space-x-3">
              <div className="relative">
                <Search className="h-4 w-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-legal-400" />
                <input
                  type="text"
                  placeholder="Rechercher un modèle..."
                  className="pl-10 pr-4 py-2 border border-legal-300 rounded-lg text-sm focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {filteredTemplates.map((template) => (
              <div
                key={template.id}
                onClick={() => {
                  setSelectedTemplate(template.id);
                  setCurrentStep(2);
                }}
                className={`p-6 border-2 rounded-lg cursor-pointer transition-all duration-200 ${
                  selectedTemplate === template.id
                    ? 'border-primary-500 bg-primary-50'
                    : 'border-legal-200 hover:border-primary-300 hover:bg-legal-50'
                }`}
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <h3 className="font-semibold text-legal-900 mb-2">
                      {template.title}
                    </h3>
                    <p className="text-legal-600 text-sm mb-3">
                      {template.description}
                    </p>
                    <div className="flex items-center space-x-2">
                      <span className={`px-2 py-1 text-xs rounded-full ${
                        template.complexity === 'simple' ? 'bg-green-100 text-green-700' :
                        template.complexity === 'medium' ? 'bg-yellow-100 text-yellow-700' :
                        'bg-red-100 text-red-700'
                      }`}>
                        {template.complexity === 'simple' ? 'Simple' :
                         template.complexity === 'medium' ? 'Moyen' : 'Complexe'}
                      </span>
                      <span className="text-xs text-legal-500">
                        {template.fields.length} champs
                      </span>
                    </div>
                  </div>
                  <FileText className={`h-6 w-6 ml-4 ${
                    selectedTemplate === template.id ? 'text-primary-600' : 'text-legal-400'
                  }`} />
                </div>
              </div>
            ))}
          </div>

          <div className="mt-8 flex justify-between">
            <button
              onClick={() => {
                setCurrentStep(1);
                setSelectedCategory('');
              }}
              className="inline-flex items-center px-6 py-3 border border-legal-300 text-legal-700 rounded-lg hover:bg-legal-50 transition-colors duration-200"
            >
              <ArrowLeft className="mr-2 h-4 w-4" />
              Retour aux catégories
            </button>
          </div>
        </div>
      )}

      {/* Step 2: Formulaire intelligent */}
      {currentStep === 2 && selectedTemplate && (
        <div className="bg-white rounded-xl shadow-sm border border-legal-200 p-8">
          <h2 className="text-xl font-semibold text-legal-900 mb-6">
            Informations pour votre {templates[selectedCategory as keyof typeof templates]?.find(t => t.id === selectedTemplate)?.title}
          </h2>

          {/* Adaptation selon le profil utilisateur */}
          {userProfile.status === 'Étudiant en droit' && (
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
              <h3 className="text-sm font-medium text-blue-900 mb-2">
                💡 Conseil pour étudiants
              </h3>
              <p className="text-sm text-blue-700">
                Ce formulaire est adapté à votre statut d'étudiant. L'IA ajoutera des explications pédagogiques dans le document généré.
              </p>
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-legal-700 mb-2">
                Demandeur / Partie requérante *
              </label>
              <input
                type="text"
                className="w-full px-3 py-2 border border-legal-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                placeholder="Nom et prénom du demandeur"
                value={formData.demandeur}
                onChange={(e) => handleInputChange('demandeur', e.target.value)}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-legal-700 mb-2">
                Défendeur / Partie adverse *
              </label>
              <input
                type="text"
                className="w-full px-3 py-2 border border-legal-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                placeholder="Nom et prénom du défendeur"
                value={formData.defendeur}
                onChange={(e) => handleInputChange('defendeur', e.target.value)}
              />
            </div>

            {selectedCategory === 'civil' && (
              <>
                <div>
                  <label className="block text-sm font-medium text-legal-700 mb-2">
                    Tribunal compétent
                  </label>
                  <select 
                    className="w-full px-3 py-2 border border-legal-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                    value={formData.tribunal}
                    onChange={(e) => handleInputChange('tribunal', e.target.value)}
                  >
                    <option value="">Sélectionner...</option>
                    <option value="tgi">Tribunal de grande instance</option>
                    <option value="commerce">Tribunal de commerce</option>
                    <option value="prudhommes">Conseil de prud'hommes</option>
                    <option value="administratif">Tribunal administratif</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-legal-700 mb-2">
                    Type de procédure
                  </label>
                  <select 
                    className="w-full px-3 py-2 border border-legal-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                    value={formData.urgence}
                    onChange={(e) => handleInputChange('urgence', e.target.value)}
                  >
                    <option value="">Sélectionner...</option>
                    <option value="refere-urgence">Référé d'urgence</option>
                    <option value="refere-provision">Référé provision</option>
                    <option value="normale">Procédure normale</option>
                  </select>
                </div>
              </>
            )}

            {(selectedTemplate.includes('montant') || selectedTemplate.includes('payer')) && (
              <div>
                <label className="block text-sm font-medium text-legal-700 mb-2">
                  Montant en jeu
                </label>
                <input
                  type="text"
                  className="w-full px-3 py-2 border border-legal-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                  placeholder="Ex: 5 000 €"
                  value={formData.montant}
                  onChange={(e) => handleInputChange('montant', e.target.value)}
                />
              </div>
            )}

            <div>
              <label className="block text-sm font-medium text-legal-700 mb-2">
                Référence client / dossier
              </label>
              <input
                type="text"
                className="w-full px-3 py-2 border border-legal-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                placeholder="Référence interne"
                value={formData.client}
                onChange={(e) => handleInputChange('client', e.target.value)}
              />
            </div>
          </div>

          <div className="mt-6">
            <label className="block text-sm font-medium text-legal-700 mb-2">
              Objet de la demande *
            </label>
            <textarea
              rows={4}
              className="w-full px-3 py-2 border border-legal-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
              placeholder="Décrivez précisément l'objet de votre demande..."
              value={formData.objet}
              onChange={(e) => handleInputChange('objet', e.target.value)}
            />
          </div>

          <div className="mt-6">
            <label className="block text-sm font-medium text-legal-700 mb-2">
              Faits et circonstances
            </label>
            <textarea
              rows={6}
              className="w-full px-3 py-2 border border-legal-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
              placeholder="Exposez les faits pertinents et les circonstances de l'affaire..."
              value={formData.faits}
              onChange={(e) => handleInputChange('faits', e.target.value)}
            />
            <p className="text-xs text-legal-500 mt-1">
              L'IA adaptera le style selon vos préférences : {
                userProfile.writingStyle === 'formal' ? 'Formel et structuré' :
                userProfile.writingStyle === 'synthetic' ? 'Synthétique et concis' :
                userProfile.writingStyle === 'detailed' ? 'Détaillé avec références' :
                'Pédagogique et explicatif'
              }
            </p>
          </div>

          <div className="mt-8 flex justify-between">
            <button
              onClick={() => setCurrentStep(1.5)}
              className="inline-flex items-center px-6 py-3 border border-legal-300 text-legal-700 rounded-lg hover:bg-legal-50 transition-colors duration-200"
            >
              <ArrowLeft className="mr-2 h-4 w-4" />
              Retour aux modèles
            </button>
            <button
              onClick={handleGenerate}
              disabled={loading || !formData.demandeur || !formData.objet}
              className={`inline-flex items-center px-6 py-3 rounded-lg transition-colors duration-200 ${
                formData.demandeur && formData.objet && !loading
                  ? 'bg-primary-600 text-white hover:bg-primary-700'
                  : 'bg-legal-300 text-legal-500 cursor-not-allowed'
              }`}
            >
              {loading ? (
                <>
                  <Loader2 className="animate-spin mr-2 h-4 w-4" />
                  Génération...
                </>
              ) : (
                <>
                  Générer l'acte
                  <ArrowRight className="ml-2 h-4 w-4" />
                </>
              )}
            </button>
          </div>
        </div>
      )}

      {/* Step 3: Résultat */}
      {currentStep === 3 && (
        <div className="space-y-8">
          <div className="bg-white rounded-xl shadow-sm border border-legal-200 p-8">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold text-legal-900">
                Document généré avec succès
              </h2>
              <div className="flex items-center text-green-600">
                <CheckCircle className="h-5 w-5 mr-2" />
                <span className="text-sm font-medium">Prêt à exporter</span>
              </div>
            </div>

            <div className="bg-legal-50 rounded-lg p-6 mb-6">
              <div className="prose prose-sm max-w-none">
                {generatedDocument ? (
                  <div className="bg-white rounded p-4 max-h-96 overflow-y-auto">
                    <pre className="whitespace-pre-wrap text-legal-800 text-sm leading-relaxed">
                      {generatedDocument}
                    </pre>
                  </div>
                ) : (
                  <div className="bg-white rounded p-6">
                    <div className="text-center mb-8">
                      <h1 className="text-xl font-bold text-legal-900 mb-2">
                        {templates[selectedCategory as keyof typeof templates]?.find(t => t.id === selectedTemplate)?.title.toUpperCase()}
                      </h1>
                      <p className="text-legal-700">
                        Document personnalisé selon votre profil
                      </p>
                    </div>

                    <div className="space-y-6 text-legal-800">
                      <div>
                        <h3 className="font-semibold mb-2">DEMANDEUR :</h3>
                        <p>{formData.demandeur}</p>
                      </div>

                      <div>
                        <h3 className="font-semibold mb-2">DÉFENDEUR :</h3>
                        <p>{formData.defendeur}</p>
                      </div>

                      <div>
                        <h3 className="font-semibold mb-2">OBJET :</h3>
                        <p>{formData.objet}</p>
                      </div>

                      {formData.faits && (
                        <div>
                          <h3 className="font-semibold mb-2">EXPOSÉ DES FAITS :</h3>
                          <p>{formData.faits}</p>
                        </div>
                      )}

                      <div>
                        <h3 className="font-semibold mb-2">MOYENS DE DROIT :</h3>
                        <p>
                          {userProfile.writingStyle === 'pedagogical' 
                            ? 'Aux termes de l\'article 544 du Code civil (droit de propriété), la propriété est le droit de jouir et disposer des choses de la manière la plus absolue...'
                            : 'Aux termes de l\'article 544 du Code civil, la propriété est le droit de jouir et disposer des choses de la manière la plus absolue...'
                          }
                        </p>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>

            <div className="mt-8 flex justify-between">
              <button
                onClick={() => setCurrentStep(2)}
                className="inline-flex items-center px-6 py-3 border border-legal-300 text-legal-700 rounded-lg hover:bg-legal-50 transition-colors duration-200"
              >
                <ArrowLeft className="mr-2 h-4 w-4" />
                Modifier
              </button>
              <div className="space-x-4">
                <button className="inline-flex items-center px-6 py-3 border border-primary-600 text-primary-600 rounded-lg hover:bg-primary-50 transition-colors duration-200">
                  <Eye className="mr-2 h-4 w-4" />
                  Aperçu PDF
                </button>
                <button 
                  onClick={() => navigate('/export')}
                  className="inline-flex items-center px-6 py-3 bg-primary-600 text-white rounded-lg hover:bg-primary-700 transition-colors duration-200"
                >
                  <Download className="mr-2 h-4 w-4" />
                  Exporter
                </button>
                <button
                  onClick={resetForm}
                  className="inline-flex items-center px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors duration-200"
                >
                  <Plus className="mr-2 h-4 w-4" />
                  Nouveau document
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default RedactionActe;