import React from 'react';
import { Link } from 'react-router-dom';
import { Scale, ArrowRight, CheckCircle, Star, Users, Clock, Shield, Zap } from 'lucide-react';

const Home: React.FC = () => {
  const features = [
    {
      icon: Clock,
      title: 'Gain de temps',
      description: 'Réduisez de 80% le temps de rédaction de vos actes juridiques',
      color: 'text-blue-600'
    },
    {
      icon: Shield,
      title: 'Conformité RGPD',
      description: 'Données sécurisées et traitées en Europe via Make.com',
      color: 'text-green-600'
    },
    {
      icon: Zap,
      title: 'IA spécialisée',
      description: 'Intelligence artificielle formée spécifiquement au droit français',
      color: 'text-purple-600'
    },
    {
      icon: Users,
      title: 'Collaboration',
      description: 'Partagez et collaborez sur vos documents en équipe',
      color: 'text-orange-600'
    }
  ];

  const testimonials = [
    {
      name: 'Maître Sophie Dubois',
      role: 'Avocate en droit des affaires',
      content: 'Juristia a révolutionné ma pratique. Je gagne 3h par jour sur la rédaction.',
      rating: 5
    },
    {
      name: 'Cabinet Martin & Associés',
      role: 'Cabinet d\'avocats',
      content: 'Un outil indispensable pour notre cabinet. La qualité des actes générés est remarquable.',
      rating: 5
    },
    {
      name: 'Maître Jean Lefebvre',
      role: 'Avocat en droit civil',
      content: 'Interface intuitive et résultats professionnels. Je recommande vivement.',
      rating: 5
    }
  ];

  const stats = [
    { number: '2000+', label: 'Avocats utilisateurs' },
    { number: '50k+', label: 'Documents générés' },
    { number: '85%', label: 'Temps économisé' },
    { number: '99.9%', label: 'Disponibilité' }
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="bg-white border-b border-legal-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <Scale className="h-8 w-8 text-primary-600" />
              <span className="ml-2 text-xl font-bold text-legal-900">Juristia</span>
            </div>
            <div className="flex items-center space-x-4">
              <Link
                to="/login"
                className="text-legal-600 hover:text-primary-600 transition-colors duration-200"
              >
                Connexion
              </Link>
              <Link
                to="/register"
                className="bg-primary-600 text-white px-4 py-2 rounded-lg hover:bg-primary-700 transition-colors duration-200"
              >
                Essai gratuit
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-primary-50 to-legal-50 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-5xl font-bold text-legal-900 mb-6 animate-fade-in">
              L'assistant juridique IA
              <span className="block text-primary-600">nouvelle génération</span>
            </h1>
            <p className="text-xl text-legal-600 mb-8 max-w-3xl mx-auto animate-slide-up">
              Rédigez vos actes juridiques, préparez vos consultations et exportez vos documents 
              avec l'intelligence artificielle la plus avancée du marché juridique français.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center animate-scale-in">
              <Link
                to="/register"
                className="inline-flex items-center px-8 py-4 bg-primary-600 text-white text-lg font-semibold rounded-lg hover:bg-primary-700 transition-all duration-200 hover:scale-105"
              >
                Commencer gratuitement
                <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
              <Link
                to="/demo"
                className="inline-flex items-center px-8 py-4 border-2 border-primary-600 text-primary-600 text-lg font-semibold rounded-lg hover:bg-primary-50 transition-colors duration-200"
              >
                Voir la démo
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-legal-900 mb-4">
              Pourquoi choisir Juristia ?
            </h2>
            <p className="text-lg text-legal-600 max-w-2xl mx-auto">
              Une solution complète pensée par et pour les professionnels du droit
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <div
                  key={index}
                  className="text-center p-6 rounded-xl border border-legal-200 hover:shadow-lg transition-all duration-300 hover:-translate-y-1 animate-slide-up"
                  style={{ animationDelay: `${index * 0.1}s` }}
                >
                  <div className={`inline-flex items-center justify-center w-16 h-16 rounded-full bg-legal-100 mb-4`}>
                    <Icon className={`h-8 w-8 ${feature.color}`} />
                  </div>
                  <h3 className="text-xl font-semibold text-legal-900 mb-2">
                    {feature.title}
                  </h3>
                  <p className="text-legal-600">
                    {feature.description}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Product Features */}
      <section className="py-20 bg-legal-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-legal-900 mb-4">
              Fonctionnalités complètes
            </h2>
            <p className="text-lg text-legal-600">
              Tout ce dont vous avez besoin pour votre pratique juridique
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="bg-white rounded-xl p-8 shadow-sm border border-legal-200 animate-slide-up">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-6">
                <Scale className="h-6 w-6 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold text-legal-900 mb-4">
                Préparation RDV
              </h3>
              <ul className="space-y-3 text-legal-600">
                <li className="flex items-center">
                  <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                  Upload de documents PDF/Audio
                </li>
                <li className="flex items-center">
                  <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                  Transcription automatique
                </li>
                <li className="flex items-center">
                  <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                  Synthèse intelligente
                </li>
                <li className="flex items-center">
                  <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                  Points clés automatiques
                </li>
              </ul>
            </div>

            <div className="bg-white rounded-xl p-8 shadow-sm border border-legal-200 animate-slide-up" style={{ animationDelay: '0.1s' }}>
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mb-6">
                <Scale className="h-6 w-6 text-purple-600" />
              </div>
              <h3 className="text-xl font-semibold text-legal-900 mb-4">
                Rédaction d'actes
              </h3>
              <ul className="space-y-3 text-legal-600">
                <li className="flex items-center">
                  <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                  Templates juridiques
                </li>
                <li className="flex items-center">
                  <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                  Citations légales automatiques
                </li>
                <li className="flex items-center">
                  <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                  Structure professionnelle
                </li>
                <li className="flex items-center">
                  <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                  Suggestions d'amélioration
                </li>
              </ul>
            </div>

            <div className="bg-white rounded-xl p-8 shadow-sm border border-legal-200 animate-slide-up" style={{ animationDelay: '0.2s' }}>
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-6">
                <Scale className="h-6 w-6 text-green-600" />
              </div>
              <h3 className="text-xl font-semibold text-legal-900 mb-4">
                Export professionnel
              </h3>
              <ul className="space-y-3 text-legal-600">
                <li className="flex items-center">
                  <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                  Formats PDF et Word
                </li>
                <li className="flex items-center">
                  <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                  Design juridique
                </li>
                <li className="flex items-center">
                  <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                  En-têtes personnalisés
                </li>
                <li className="flex items-center">
                  <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                  Filigrane sécurisé
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20 bg-primary-600">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-white mb-4">
              Ils nous font confiance
            </h2>
            <p className="text-lg text-primary-100">
              Rejoignez des milliers d'avocats qui utilisent Juristia quotidiennement
            </p>
          </div>

          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div
                key={index}
                className="text-center animate-scale-in"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <div className="text-4xl font-bold text-white mb-2">
                  {stat.number}
                </div>
                <div className="text-primary-100">
                  {stat.label}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-legal-900 mb-4">
              Ce que disent nos utilisateurs
            </h2>
            <p className="text-lg text-legal-600">
              Découvrez les témoignages de professionnels du droit
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <div
                key={index}
                className="bg-legal-50 rounded-xl p-8 animate-slide-up"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <div className="flex items-center mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="h-5 w-5 text-yellow-400 fill-current" />
                  ))}
                </div>
                <p className="text-legal-700 mb-6 italic">
                  "{testimonial.content}"
                </p>
                <div>
                  <div className="font-semibold text-legal-900">
                    {testimonial.name}
                  </div>
                  <div className="text-legal-600 text-sm">
                    {testimonial.role}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-primary-600 to-primary-700">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-white mb-4">
            Prêt à révolutionner votre pratique juridique ?
          </h2>
          <p className="text-xl text-primary-100 mb-8">
            Rejoignez Juristia dès aujourd'hui et découvrez l'avenir de l'assistance juridique
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/register"
              className="inline-flex items-center px-8 py-4 bg-white text-primary-600 text-lg font-semibold rounded-lg hover:bg-legal-50 transition-colors duration-200"
            >
              Commencer l'essai gratuit
              <ArrowRight className="ml-2 h-5 w-5" />
            </Link>
            <Link
              to="/contact"
              className="inline-flex items-center px-8 py-4 border-2 border-white text-white text-lg font-semibold rounded-lg hover:bg-white hover:text-primary-600 transition-colors duration-200"
            >
              Nous contacter
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-legal-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center mb-4">
                <Scale className="h-6 w-6 text-primary-400" />
                <span className="ml-2 text-lg font-bold">Juristia</span>
              </div>
              <p className="text-legal-300">
                L'assistant juridique IA nouvelle génération pour les professionnels du droit.
              </p>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Produit</h3>
              <ul className="space-y-2 text-legal-300">
                <li><Link to="/features" className="hover:text-white transition-colors">Fonctionnalités</Link></li>
                <li><Link to="/pricing" className="hover:text-white transition-colors">Tarifs</Link></li>
                <li><Link to="/demo" className="hover:text-white transition-colors">Démo</Link></li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Support</h3>
              <ul className="space-y-2 text-legal-300">
                <li><Link to="/help" className="hover:text-white transition-colors">Centre d'aide</Link></li>
                <li><Link to="/contact" className="hover:text-white transition-colors">Contact</Link></li>
                <li><Link to="/status" className="hover:text-white transition-colors">Statut</Link></li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Légal</h3>
              <ul className="space-y-2 text-legal-300">
                <li><Link to="/privacy" className="hover:text-white transition-colors">Confidentialité</Link></li>
                <li><Link to="/terms" className="hover:text-white transition-colors">CGU</Link></li>
                <li><Link to="/security" className="hover:text-white transition-colors">Sécurité</Link></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-legal-800 mt-8 pt-8 text-center text-legal-400">
            <p>&copy; 2025 Juristia. Tous droits réservés. Conforme RGPD.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Home;