import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Upload, Mic, FileText, ArrowRight, CheckCircle, ArrowLeft, Download, Eye, Loader2 } from 'lucide-react';
import { useMakeIntegration } from '../hooks/useMakeIntegration';

const PreparationRDV: React.FC = () => {
  const [currentStep, setCurrentStep] = useState(1);
  const [isRecording, setIsRecording] = useState(false);
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [synthesizedContent, setSynthesizedContent] = useState<string>('');
  const { loading, error, synthesize, transcribe } = useMakeIntegration();
  
  const [formData, setFormData] = useState({
    consultationType: '',
    legalDomain: '',
    notes: '',
    demandeur: '',
    defendeur: ''
  });

  const steps = [
    { id: 1, title: 'Upload/Transcription', description: 'Importez vos documents ou enregistrez' },
    { id: 2, title: 'Aperçu & Édition', description: 'Vérifiez et modifiez le contenu' },
    { id: 3, title: 'Résultat & Export', description: 'Obtenez votre résumé finalisé' },
  ];

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setUploadedFile(file);
      
      // Si c'est un PDF, on lance la synthèse via Make.com
      if (file.type === 'application/pdf') {
        const fileUrl = URL.createObjectURL(file);
        const result = await synthesize(fileUrl, formData.consultationType || 'consultation');
        if (result) {
          setSynthesizedContent(result.summary || result.content);
        }
      }
      
      // Si c'est un fichier audio, on lance la transcription
      if (file.type.startsWith('audio/')) {
        const result = await transcribe(file);
        if (result) {
          setSynthesizedContent(result.transcription || result.text);
        }
      }
    }
  };

  const toggleRecording = async () => {
    if (!isRecording) {
      setIsRecording(true);
      // Simuler l'enregistrement - en production, utiliser l'API Web Audio
      setTimeout(async () => {
        setIsRecording(false);
        // Simuler un fichier audio pour la démo
        const mockAudioBlob = new Blob(['mock audio data'], { type: 'audio/wav' });
        const mockFile = new File([mockAudioBlob], 'recording.wav', { type: 'audio/wav' });
        
        const result = await transcribe(mockFile);
        if (result) {
          setSynthesizedContent(result.transcription || 'Transcription de l\'enregistrement vocal...');
        }
      }, 3000);
    } else {
      setIsRecording(false);
    }
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const canProceedToStep2 = uploadedFile || isRecording || formData.notes.trim().length > 0 || synthesizedContent;

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-fade-in">
      {/* Header with breadcrumb */}
      <div className="mb-8">
        <nav className="flex items-center space-x-2 text-sm text-legal-600 mb-4">
          <Link to="/" className="hover:text-primary-600 transition-colors duration-200">Dashboard</Link>
          <span>/</span>
          <span className="text-legal-900 font-medium">Préparation RDV</span>
        </nav>
        <h1 className="text-3xl font-bold text-legal-900 mb-2">
          Préparation de rendez-vous
        </h1>
        <p className="text-legal-600">
          Préparez efficacement vos consultations avec l'aide de l'IA
        </p>
      </div>

      {/* Progress Steps */}
      <div className="mb-8">
        <div className="flex items-center justify-between">
          {steps.map((step, index) => (
            <div key={step.id} className="flex items-center">
              <div className={`flex items-center justify-center w-10 h-10 rounded-full border-2 transition-all duration-300 ${
                currentStep >= step.id 
                  ? 'bg-primary-600 border-primary-600 text-white' 
                  : 'border-legal-300 text-legal-400'
              }`}>
                {currentStep > step.id ? (
                  <CheckCircle className="h-5 w-5" />
                ) : (
                  <span className="text-sm font-medium">{step.id}</span>
                )}
              </div>
              <div className="ml-3">
                <p className={`text-sm font-medium ${
                  currentStep >= step.id ? 'text-legal-900' : 'text-legal-500'
                }`}>
                  {step.title}
                </p>
                <p className="text-xs text-legal-500">{step.description}</p>
              </div>
              {index < steps.length - 1 && (
                <div className={`mx-6 h-0.5 w-16 transition-all duration-300 ${
                  currentStep > step.id ? 'bg-primary-600' : 'bg-legal-300'
                }`} />
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Loading State */}
      {loading && (
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-6 mb-6">
          <div className="flex items-center">
            <Loader2 className="h-6 w-6 text-blue-600 animate-spin mr-3" />
            <div>
              <h3 className="text-lg font-medium text-blue-900">
                Traitement en cours...
              </h3>
              <p className="text-blue-700">
                L'IA analyse votre document via Make.com
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Error State */}
      {error && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-6 mb-6">
          <div className="flex items-center">
            <div className="text-red-600 mr-3">⚠️</div>
            <div>
              <h3 className="text-lg font-medium text-red-900">
                Erreur de traitement
              </h3>
              <p className="text-red-700">{error}</p>
            </div>
          </div>
        </div>
      )}

      {/* Step Content */}
      {currentStep === 1 && (
        <div className="bg-white rounded-xl shadow-sm border border-legal-200 p-8 animate-slide-up">
          <h2 className="text-xl font-semibold text-legal-900 mb-6">
            Étape 1: Upload/Transcription
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* File Upload */}
            <div className="border-2 border-dashed border-legal-300 rounded-lg p-6 text-center hover:border-primary-400 transition-colors duration-200">
              <Upload className="h-12 w-12 text-legal-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-legal-900 mb-2">
                Importer un document
              </h3>
              <p className="text-legal-600 mb-4">
                PDF, Word, ou fichier audio
              </p>
              <input
                type="file"
                onChange={handleFileUpload}
                className="hidden"
                id="file-upload"
                accept=".pdf,.doc,.docx,.mp3,.wav,.m4a"
                disabled={loading}
              />
              <label
                htmlFor="file-upload"
                className={`inline-flex items-center px-4 py-2 rounded-lg transition-colors duration-200 cursor-pointer ${
                  loading 
                    ? 'bg-legal-300 text-legal-500 cursor-not-allowed'
                    : 'bg-primary-600 text-white hover:bg-primary-700'
                }`}
              >
                {loading ? 'Traitement...' : 'Choisir un fichier'}
              </label>
              {uploadedFile && (
                <p className="mt-2 text-sm text-green-600">
                  ✓ {uploadedFile.name}
                </p>
              )}
            </div>

            {/* Voice Recording */}
            <div className="border-2 border-dashed border-legal-300 rounded-lg p-6 text-center hover:border-primary-400 transition-colors duration-200">
              <Mic className={`h-12 w-12 mx-auto mb-4 transition-colors duration-200 ${
                isRecording ? 'text-red-500' : 'text-legal-400'
              }`} />
              <h3 className="text-lg font-medium text-legal-900 mb-2">
                Enregistrement vocal
              </h3>
              <p className="text-legal-600 mb-4">
                Dictez directement vos notes
              </p>
              <button
                onClick={toggleRecording}
                disabled={loading}
                className={`inline-flex items-center px-4 py-2 rounded-lg transition-colors duration-200 ${
                  loading
                    ? 'bg-legal-300 text-legal-500 cursor-not-allowed'
                    : isRecording 
                      ? 'bg-red-600 text-white hover:bg-red-700' 
                      : 'bg-primary-600 text-white hover:bg-primary-700'
                }`}
              >
                {loading ? 'Traitement...' : isRecording ? 'Arrêter' : 'Commencer'} l'enregistrement
              </button>
              {isRecording && (
                <div className="mt-2 flex items-center justify-center">
                  <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse mr-2"></div>
                  <span className="text-sm text-red-600">Enregistrement en cours...</span>
                </div>
              )}
            </div>
          </div>

          {/* Synthesized Content Preview */}
          {synthesizedContent && (
            <div className="mt-8 bg-green-50 border border-green-200 rounded-lg p-6">
              <h3 className="text-lg font-medium text-green-900 mb-3 flex items-center">
                <CheckCircle className="h-5 w-5 mr-2" />
                Contenu analysé par l'IA
              </h3>
              <div className="bg-white rounded p-4 text-legal-800">
                <pre className="whitespace-pre-wrap text-sm">{synthesizedContent}</pre>
              </div>
            </div>
          )}

          {/* Form Fields */}
          <div className="mt-8 space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-legal-700 mb-2">
                  Type de consultation
                </label>
                <select 
                  className="w-full px-3 py-2 border border-legal-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                  value={formData.consultationType}
                  onChange={(e) => handleInputChange('consultationType', e.target.value)}
                >
                  <option value="">Sélectionner...</option>
                  <option value="initial">Consultation initiale</option>
                  <option value="suivi">Suivi de dossier</option>
                  <option value="conseil">Conseil juridique</option>
                  <option value="mediation">Médiation</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-legal-700 mb-2">
                  Domaine juridique
                </label>
                <select 
                  className="w-full px-3 py-2 border border-legal-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                  value={formData.legalDomain}
                  onChange={(e) => handleInputChange('legalDomain', e.target.value)}
                >
                  <option value="">Sélectionner...</option>
                  <option value="civil">Droit civil</option>
                  <option value="commercial">Droit commercial</option>
                  <option value="travail">Droit du travail</option>
                  <option value="penal">Droit pénal</option>
                  <option value="administratif">Droit administratif</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-legal-700 mb-2">
                Notes préliminaires
              </label>
              <textarea
                rows={4}
                className="w-full px-3 py-2 border border-legal-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                placeholder="Ajoutez vos notes ou observations préliminaires..."
                value={formData.notes}
                onChange={(e) => handleInputChange('notes', e.target.value)}
              />
            </div>
          </div>

          <div className="mt-8 flex justify-between">
            <Link
              to="/"
              className="inline-flex items-center px-6 py-3 border border-legal-300 text-legal-700 rounded-lg hover:bg-legal-50 transition-colors duration-200"
            >
              <ArrowLeft className="mr-2 h-4 w-4" />
              Retour au dashboard
            </Link>
            <button
              onClick={() => setCurrentStep(2)}
              disabled={!canProceedToStep2 || loading}
              className={`inline-flex items-center px-6 py-3 rounded-lg transition-colors duration-200 ${
                canProceedToStep2 && !loading
                  ? 'bg-primary-600 text-white hover:bg-primary-700'
                  : 'bg-legal-300 text-legal-500 cursor-not-allowed'
              }`}
            >
              Continuer
              <ArrowRight className="ml-2 h-4 w-4" />
            </button>
          </div>
        </div>
      )}

      {currentStep === 2 && (
        <div className="bg-white rounded-xl shadow-sm border border-legal-200 p-8 animate-slide-up">
          <h2 className="text-xl font-semibold text-legal-900 mb-6">
            Étape 2: Aperçu & Édition
          </h2>

          <div className="space-y-6">
            <div className="bg-legal-50 rounded-lg p-6">
              <h3 className="text-lg font-medium text-legal-900 mb-4">
                Résumé généré par l'IA via Make.com
              </h3>
              <div className="prose prose-sm max-w-none">
                {synthesizedContent ? (
                  <div className="bg-white rounded p-4">
                    <pre className="whitespace-pre-wrap text-legal-700">{synthesizedContent}</pre>
                  </div>
                ) : (
                  <div className="text-legal-700 leading-relaxed">
                    <p><strong>Client :</strong> Mme Marie Dupont<br/>
                    <strong>Objet :</strong> Consultation en droit du travail - Licenciement abusif<br/>
                    <strong>Contexte :</strong> La cliente souhaite contester son licenciement pour motif économique, estimant qu'il s'agit d'un licenciement déguisé suite à un conflit avec sa hiérarchie.</p>
                    
                    <p className="mt-4"><strong>Points clés à aborder :</strong></p>
                    <ul className="list-disc list-inside space-y-1">
                      <li>Vérification de la procédure de licenciement économique</li>
                      <li>Analyse des motifs invoqués par l'employeur</li>
                      <li>Évaluation des preuves de discrimination</li>
                      <li>Calcul des indemnités potentielles</li>
                    </ul>
                  </div>
                )}
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-legal-700 mb-2">
                Modifications et ajouts
              </label>
              <textarea
                rows={6}
                className="w-full px-3 py-2 border border-legal-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                placeholder="Ajoutez vos modifications ou informations complémentaires..."
              />
            </div>
          </div>

          <div className="mt-8 flex justify-between">
            <button
              onClick={() => setCurrentStep(1)}
              className="inline-flex items-center px-6 py-3 border border-legal-300 text-legal-700 rounded-lg hover:bg-legal-50 transition-colors duration-200"
            >
              <ArrowLeft className="mr-2 h-4 w-4" />
              Retour
            </button>
            <button
              onClick={() => setCurrentStep(3)}
              className="inline-flex items-center px-6 py-3 bg-primary-600 text-white rounded-lg hover:bg-primary-700 transition-colors duration-200"
            >
              Finaliser
              <ArrowRight className="ml-2 h-4 w-4" />
            </button>
          </div>
        </div>
      )}

      {currentStep === 3 && (
        <div className="bg-white rounded-xl shadow-sm border border-legal-200 p-8 animate-slide-up">
          <h2 className="text-xl font-semibold text-legal-900 mb-6">
            Étape 3: Résultat & Export
          </h2>

          <div className="bg-green-50 border border-green-200 rounded-lg p-6 mb-6">
            <div className="flex items-center">
              <CheckCircle className="h-6 w-6 text-green-600 mr-3" />
              <div>
                <h3 className="text-lg font-medium text-green-900">
                  Préparation terminée avec succès
                </h3>
                <p className="text-green-700">
                  Votre résumé de consultation est prêt à être utilisé
                </p>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            <Link
              to="/export"
              className="flex items-center justify-center p-6 border-2 border-legal-300 rounded-lg hover:border-primary-400 hover:bg-primary-50 transition-all duration-200 group"
            >
              <Download className="h-8 w-8 text-primary-600 mr-3 group-hover:scale-110 transition-transform duration-200" />
              <div className="text-left">
                <h3 className="font-medium text-legal-900">Exporter en PDF</h3>
                <p className="text-sm text-legal-600">Format professionnel</p>
              </div>
            </Link>

            <Link
              to="/export"
              className="flex items-center justify-center p-6 border-2 border-legal-300 rounded-lg hover:border-primary-400 hover:bg-primary-50 transition-all duration-200 group"
            >
              <FileText className="h-8 w-8 text-primary-600 mr-3 group-hover:scale-110 transition-transform duration-200" />
              <div className="text-left">
                <h3 className="font-medium text-legal-900">Exporter en Word</h3>
                <p className="text-sm text-legal-600">Format éditable</p>
              </div>
            </Link>

            <button className="flex items-center justify-center p-6 border-2 border-legal-300 rounded-lg hover:border-primary-400 hover:bg-primary-50 transition-all duration-200 group">
              <Eye className="h-8 w-8 text-primary-600 mr-3 group-hover:scale-110 transition-transform duration-200" />
              <div className="text-left">
                <h3 className="font-medium text-legal-900">Aperçu</h3>
                <p className="text-sm text-legal-600">Visualiser le résultat</p>
              </div>
            </button>
          </div>

          <div className="mt-8 flex justify-between">
            <button
              onClick={() => setCurrentStep(2)}
              className="inline-flex items-center px-6 py-3 border border-legal-300 text-legal-700 rounded-lg hover:bg-legal-50 transition-colors duration-200"
            >
              <ArrowLeft className="mr-2 h-4 w-4" />
              Retour
            </button>
            <div className="space-x-4">
              <button
                onClick={() => setCurrentStep(1)}
                className="inline-flex items-center px-6 py-3 border border-primary-600 text-primary-600 rounded-lg hover:bg-primary-50 transition-colors duration-200"
              >
                Nouvelle préparation
              </button>
              <Link
                to="/"
                className="inline-flex items-center px-6 py-3 bg-primary-600 text-white rounded-lg hover:bg-primary-700 transition-colors duration-200"
              >
                Retour au dashboard
              </Link>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default PreparationRDV;