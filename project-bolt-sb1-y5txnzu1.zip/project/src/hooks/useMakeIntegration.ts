import { useState } from 'react';
import { 
  synthesizeDocument, 
  generateLegalDocument, 
  transcribeAudio, 
  exportDocument,
  analyzeLegalText,
  MakeResponse 
} from '../services/makeApi';

export interface MakeState {
  loading: boolean;
  error: string | null;
  data: any;
}

export function useMakeIntegration() {
  const [state, setState] = useState<MakeState>({
    loading: false,
    error: null,
    data: null
  });

  const handleMakeCall = async (makeFunction: () => Promise<MakeResponse>) => {
    setState({ loading: true, error: null, data: null });
    
    try {
      const result = await makeFunction();
      
      if (result.success) {
        setState({ loading: false, error: null, data: result.data });
        return result.data;
      } else {
        setState({ loading: false, error: result.error || 'Erreur inconnue', data: null });
        return null;
      }
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Erreur inconnue';
      setState({ loading: false, error: errorMessage, data: null });
      return null;
    }
  };

  // Synthèse de document
  const synthesize = async (pdfUrl: string, documentType: string) => {
    return handleMakeCall(() => synthesizeDocument(pdfUrl, documentType));
  };

  // Génération d'acte juridique
  const generateDocument = async (formData: any, templateType: string) => {
    return handleMakeCall(() => generateLegalDocument(formData, templateType));
  };

  // Transcription audio
  const transcribe = async (audioFile: File) => {
    return handleMakeCall(() => transcribeAudio(audioFile));
  };

  // Export document
  const exportDoc = async (documentData: any, format: string, template: string) => {
    return handleMakeCall(() => exportDocument(documentData, format, template));
  };

  // Analyse juridique
  const analyze = async (text: string, legalDomain: string) => {
    return handleMakeCall(() => analyzeLegalText(text, legalDomain));
  };

  const reset = () => {
    setState({ loading: false, error: null, data: null });
  };

  return {
    ...state,
    synthesize,
    generateDocument,
    transcribe,
    exportDoc,
    analyze,
    reset
  };
}