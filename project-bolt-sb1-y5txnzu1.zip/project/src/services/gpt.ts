// Service GPT pour Make.com
export interface GPTResponse {
  content: string;
  usage?: {
    prompt_tokens: number;
    completion_tokens: number;
    total_tokens: number;
  };
}

export async function getGPTResponse(prompt: string, context?: any): Promise<string> {
  try {
    // Cette fonction sera appelée par Make.com
    // Le prompt sera envoyé à OpenAI via Make.com
    const response = await fetch('/api/gpt', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        prompt,
        context,
        model: 'gpt-4',
        max_tokens: 2000,
        temperature: 0.3
      })
    });

    const result = await response.json();
    return result.content || result.choices?.[0]?.message?.content || '';
  } catch (error) {
    console.error('Erreur GPT:', error);
    throw new Error('Erreur lors de la communication avec l\'IA');
  }
}

// Fonction spécialisée pour la synthèse juridique
export async function synthesizeJuridicalText(text: string, documentType: string): Promise<string> {
  const prompt = `
En tant qu'assistant juridique expert, analysez et résumez ce document juridique de type "${documentType}".

Structurez votre réponse ainsi :
1. **Résumé exécutif** (2-3 phrases)
2. **Points clés** (liste à puces)
3. **Parties impliquées**
4. **Enjeux juridiques**
5. **Actions recommandées**

Texte à analyser :
${text}

Réponse structurée et professionnelle :`;

  return await getGPTResponse(prompt);
}

// Fonction pour la génération d'actes
export async function generateLegalAct(formData: any, templateType: string): Promise<string> {
  const prompt = `
En tant qu'expert en rédaction juridique, rédigez un ${templateType} professionnel avec les informations suivantes :

Demandeur : ${formData.demandeur}
Défendeur : ${formData.defendeur}
Tribunal : ${formData.tribunal}
Objet : ${formData.objet}
Faits : ${formData.faits}

Structurez le document selon les standards juridiques français :
1. En-tête avec juridiction
2. Identification des parties
3. Exposé des faits
4. Moyens de droit avec citations légales
5. Demandes et conclusions
6. Formule de politesse

Rédigez un document professionnel et conforme :`;

  return await getGPTResponse(prompt, { templateType, formData });
}