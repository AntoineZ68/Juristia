import React from 'react';

// Service pour communiquer avec la fonction Netlify askGPT
export interface AIMessage {
  role: 'user' | 'assistant' | 'system';
  content: string;
}

export interface AIResponse {
  response: string;
  usage?: {
    prompt_tokens: number;
    completion_tokens: number;
    total_tokens: number;
  };
  model?: string;
  timestamp?: string;
}

export interface AIError {
  error: string;
  details?: string;
  code?: string;
}

// Configuration de l'endpoint API
const API_ENDPOINT = '/.netlify/functions/askGPT';

// Fonction principale pour communiquer avec l'IA
export async function askGPT(
  messages: AIMessage[],
  userProfile?: any,
  context?: any
): Promise<AIResponse> {
  try {
    console.log('🚀 Appel API OpenAI via Netlify Functions...');
    
    const response = await fetch(API_ENDPOINT, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        messages,
        userProfile,
        context
      }),
    });

    const data = await response.json();

    if (!response.ok) {
      console.error('❌ Erreur API:', data);
      
      // Messages d'erreur plus explicites
      let errorMessage = data.error || `Erreur HTTP: ${response.status}`;
      
      if (response.status === 500 && data.details?.includes('Clé API')) {
        errorMessage = 'Configuration OpenAI manquante. Vérifiez les variables d\'environnement Netlify.';
      } else if (response.status === 401) {
        errorMessage = 'Clé API OpenAI invalide ou expirée.';
      } else if (response.status === 429) {
        errorMessage = 'Limite de requêtes OpenAI atteinte. Réessayez dans quelques minutes.';
      } else if (response.status === 404) {
        errorMessage = 'Fonction Netlify non trouvée. Vérifiez le déploiement.';
      }
      
      throw new Error(errorMessage);
    }

    console.log('✅ Réponse IA reçue avec succès');
    return data;
  } catch (error) {
    console.error('💥 Erreur lors de l\'appel à l\'IA:', error);
    
    // Gestion des erreurs réseau
    if (error instanceof Error && error.message.includes('Failed to fetch')) {
      throw new Error('Impossible de contacter le serveur IA. Vérifiez votre connexion internet et le déploiement Netlify.');
    }
    
    throw error;
  }
}

// Fonction spécialisée pour les questions juridiques simples
export async function askJuridicalQuestion(
  question: string,
  userProfile?: any,
  context?: any
): Promise<string> {
  const messages: AIMessage[] = [
    {
      role: 'user',
      content: question
    }
  ];

  const response = await askGPT(messages, userProfile, context);
  return response.response;
}

// Fonction pour la synthèse de documents
export async function synthesizeDocument(
  documentContent: string,
  documentType: string,
  userProfile?: any
): Promise<string> {
  const prompt = `En tant qu'expert juridique, analyse et résume ce document de type "${documentType}".

Structure ta réponse ainsi :
1. **Résumé exécutif** (2-3 phrases)
2. **Parties impliquées**
3. **Points clés juridiques**
4. **Enjeux et risques**
5. **Actions recommandées**

Document à analyser :
${documentContent}`;

  const messages: AIMessage[] = [
    {
      role: 'user',
      content: prompt
    }
  ];

  const context = {
    module: 'preparation-rdv',
    action: 'synthesize',
    documentType
  };

  const response = await askGPT(messages, userProfile, context);
  return response.response;
}

// Fonction pour la génération d'actes juridiques
export async function generateLegalDocument(
  formData: any,
  templateType: string,
  userProfile?: any
): Promise<string> {
  const prompt = `En tant qu'expert en rédaction juridique française, rédige un ${templateType} professionnel avec les informations suivantes :

INFORMATIONS FOURNIES :
- Demandeur : ${formData.demandeur || 'Non spécifié'}
- Défendeur : ${formData.defendeur || 'Non spécifié'}
- Objet : ${formData.objet || 'Non spécifié'}
- Faits : ${formData.faits || 'Non spécifié'}
${formData.tribunal ? `- Tribunal : ${formData.tribunal}` : ''}
${formData.montant ? `- Montant : ${formData.montant}` : ''}
${formData.urgence ? `- Type de procédure : ${formData.urgence}` : ''}

INSTRUCTIONS DE RÉDACTION :
1. Respecte la structure juridique française standard
2. Inclus les mentions obligatoires
3. Utilise le vocabulaire juridique approprié
4. Cite les articles de loi pertinents
5. Adapte le style selon le profil utilisateur
6. Assure-toi que le document soit professionnel et utilisable

Rédige un document complet et conforme aux standards du barreau français.`;

  const messages: AIMessage[] = [
    {
      role: 'user',
      content: prompt
    }
  ];

  const context = {
    module: 'redaction-acte',
    action: 'generate',
    templateType,
    category: formData.category
  };

  const response = await askGPT(messages, userProfile, context);
  return response.response;
}

// Fonction pour l'analyse juridique
export async function analyzeLegalText(
  text: string,
  analysisType: string,
  userProfile?: any
): Promise<string> {
  const prompt = `Effectue une analyse juridique approfondie de type "${analysisType}" sur ce texte :

TEXTE À ANALYSER :
${text}

ANALYSE DEMANDÉE :
- Identifie les questions juridiques soulevées
- Cite les textes de loi applicables
- Mentionne la jurisprudence pertinente
- Évalue les risques juridiques
- Propose des recommandations pratiques

Fournis une analyse structurée et professionnelle.`;

  const messages: AIMessage[] = [
    {
      role: 'user',
      content: prompt
    }
  ];

  const context = {
    module: 'analysis',
    action: 'analyze',
    analysisType
  };

  const response = await askGPT(messages, userProfile, context);
  return response.response;
}

// Hook React pour gérer l'état des appels IA
export function useAI() {
  const [loading, setLoading] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);

  const callAI = async <T>(
    aiFunction: () => Promise<T>
  ): Promise<T | null> => {
    setLoading(true);
    setError(null);

    try {
      const result = await aiFunction();
      return result;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Erreur inconnue';
      setError(errorMessage);
      console.error('🔥 Erreur dans useAI:', errorMessage);
      return null;
    } finally {
      setLoading(false);
    }
  };

  return {
    loading,
    error,
    callAI,
    clearError: () => setError(null)
  };
}

// Fonction de test de connexion
export async function testAIConnection(): Promise<boolean> {
  try {
    const response = await askJuridicalQuestion(
      'Test de connexion - réponds simplement "Connexion OK"',
      {},
      { module: 'test' }
    );
    return response.includes('Connexion OK') || response.includes('connexion') || response.length > 0;
  } catch (error) {
    console.error('Test de connexion échoué:', error);
    return false;
  }
}