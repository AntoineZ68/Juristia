// Service pour intégrer avec Make.com
const MAKE_WEBHOOK_BASE_URL = import.meta.env.VITE_MAKE_WEBHOOK_URL || 'https://hook.eu1.make.com/your-webhook-id';

export interface MakeResponse {
  success: boolean;
  data?: any;
  error?: string;
}

// Scénario 1: Synthèse de document
export async function synthesizeDocument(pdfUrl: string, documentType: string): Promise<MakeResponse> {
  try {
    const response = await fetch(`${MAKE_WEBHOOK_BASE_URL}/synthesize`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        pdfUrl,
        documentType,
        action: 'synthesize'
      })
    });

    const result = await response.json();
    return { success: true, data: result };
  } catch (error) {
    console.error('Erreur synthèse document:', error);
    return { success: false, error: 'Erreur lors de la synthèse du document' };
  }
}

// Scénario 2: Génération d'acte juridique
export async function generateLegalDocument(formData: any, templateType: string): Promise<MakeResponse> {
  try {
    const response = await fetch(`${MAKE_WEBHOOK_BASE_URL}/generate-document`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        ...formData,
        templateType,
        action: 'generate_legal_document'
      })
    });

    const result = await response.json();
    return { success: true, data: result };
  } catch (error) {
    console.error('Erreur génération document:', error);
    return { success: false, error: 'Erreur lors de la génération du document' };
  }
}

// Scénario 3: Transcription audio
export async function transcribeAudio(audioFile: File): Promise<MakeResponse> {
  try {
    const formData = new FormData();
    formData.append('audio', audioFile);
    formData.append('action', 'transcribe_audio');

    const response = await fetch(`${MAKE_WEBHOOK_BASE_URL}/transcribe`, {
      method: 'POST',
      body: formData
    });

    const result = await response.json();
    return { success: true, data: result };
  } catch (error) {
    console.error('Erreur transcription audio:', error);
    return { success: false, error: 'Erreur lors de la transcription audio' };
  }
}

// Scénario 4: Export professionnel
export async function exportDocument(documentData: any, format: string, template: string): Promise<MakeResponse> {
  try {
    const response = await fetch(`${MAKE_WEBHOOK_BASE_URL}/export`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        documentData,
        format,
        template,
        action: 'export_document'
      })
    });

    const result = await response.json();
    return { success: true, data: result };
  } catch (error) {
    console.error('Erreur export document:', error);
    return { success: false, error: 'Erreur lors de l\'export du document' };
  }
}

// Scénario 5: Analyse juridique avec citations
export async function analyzeLegalText(text: string, legalDomain: string): Promise<MakeResponse> {
  try {
    const response = await fetch(`${MAKE_WEBHOOK_BASE_URL}/analyze`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        text,
        legalDomain,
        action: 'analyze_legal_text'
      })
    });

    const result = await response.json();
    return { success: true, data: result };
  } catch (error) {
    console.error('Erreur analyse juridique:', error);
    return { success: false, error: 'Erreur lors de l\'analyse juridique' };
  }
}