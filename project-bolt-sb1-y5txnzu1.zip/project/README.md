# Juristia - Assistant Juridique IA

Application web moderne pour l'assistance juridique avec intégration OpenAI via Netlify Functions.

## 🚀 Fonctionnalités

### 📋 Dashboard
- Vue d'ensemble des activités
- Assistant IA juridique intégré
- Profil utilisateur personnalisé
- Historique des demandes
- Veille juridique personnalisée

### 📅 Préparation RDV
- Upload de documents PDF/Word/Audio
- Transcription automatique
- Synthèse intelligente par l'IA
- Workflow guidé en 3 étapes

### ⚖️ Rédaction d'acte
- Templates juridiques prédéfinis
- Génération automatique par l'IA
- Citations légales automatiques
- Suggestions d'amélioration personnalisées

### 📄 Export professionnel
- Formats PDF et Word
- Templates de design juridique
- Options avancées (filigrane, en-tête, etc.)

## 🔧 Architecture technique

### Frontend
- **React 18** avec TypeScript
- **Tailwind CSS** pour le design
- **React Router** pour la navigation
- **Lucide React** pour les icônes

### Backend (Netlify Functions)
- **Fonction askGPT** pour l'intégration OpenAI
- **Sécurisation** des clés API côté serveur
- **CORS** configuré pour les appels frontend

### Services IA
- **OpenAI GPT-4** via Netlify Functions
- Prompts spécialisés juridiques adaptés au profil utilisateur
- Gestion des erreurs et retry automatique

## 📁 Structure du projet

```
src/
├── components/          # Composants réutilisables
│   ├── Layout.tsx      # Layout principal
│   └── ProtectedRoute.tsx
├── pages/              # Pages de l'application
│   ├── Dashboard.tsx   # Tableau de bord avec IA
│   ├── PreparationRDV.tsx
│   ├── RedactionActe.tsx
│   └── Export.tsx
├── services/           # Services API
│   └── aiService.ts    # Service pour Netlify Functions
└── hooks/              # Hooks personnalisés

netlify/
└── functions/          # Fonctions serverless
    └── askGPT.js      # Fonction OpenAI
```

## 🛠️ Configuration

### Variables d'environnement Netlify

Dans le dashboard Netlify, configurez :

```env
OPENAI_API_KEY=your-openai-api-key-here
```

⚠️ **Important** : Ne mettez jamais votre clé OpenAI dans le frontend !

### Configuration locale

Créez un fichier `.env` pour le développement local :

```env
OPENAI_API_KEY=your-openai-api-key-here
```

## 🚀 Installation et démarrage

```bash
# Installation des dépendances
npm install

# Démarrage en développement
npm run dev

# Build pour production
npm run build

# Test des fonctions Netlify en local
netlify dev
```

## 🤖 Utilisation de l'IA

### Configuration OpenAI

1. **Variables d'environnement Netlify** (OBLIGATOIRE)
   - Connectez-vous à votre dashboard Netlify
   - Allez dans Site settings > Environment variables
   - Ajoutez `OPENAI_API_KEY` avec votre clé API OpenAI
   - ⚠️ **IMPORTANT** : Configurez la clé pour TOUS les contextes :
     - Production
     - Deploy Previews  
     - Branch deploys
     - Preview Server

2. **Test de connexion**
   - Un indicateur de statut IA s'affiche sur le dashboard
   - Vert = Connexion OK
   - Rouge = Problème de configuration
   - Cliquez sur "Tester" pour vérifier manuellement

### Appel simple depuis React

```typescript
import { askJuridicalQuestion } from '../services/aiService';

const response = await askJuridicalQuestion(
  "Quelle est la procédure de divorce ?",
  userProfile,
  { module: 'dashboard' }
);
```

### Appel avec hook React

```typescript
import { useAI } from '../services/aiService';

const { loading, error, callAI } = useAI();

const handleAICall = async () => {
  const result = await callAI(async () => {
    return await askJuridicalQuestion(question, userProfile);
  });
};
```

## 🔐 Sécurité

- Clés API stockées côté serveur uniquement
- CORS configuré pour les domaines autorisés
- Validation des entrées utilisateur
- Gestion des erreurs sécurisée

## 📱 Responsive Design

- Design adaptatif mobile/tablette/desktop
- Navigation optimisée tactile
- Animations fluides
- Accessibilité WCAG

## 🎨 Design System

### Couleurs
- **Primary** : Bleu professionnel (#2563eb)
- **Legal** : Gamme de gris (#0f172a à #f8fafc)
- **Accent** : Violet (#d946ef)

### Typographie
- **Font** : Inter (Google Fonts)
- **Poids** : 300, 400, 500, 600, 700

## 🚀 Déploiement

L'application est configurée pour Netlify avec :

- Build automatique depuis Git
- Fonctions serverless intégrées
- Redirections SPA configurées
- Variables d'environnement sécurisées

## 🤝 Contribution

1. Fork le projet
2. Créer une branche feature
3. Commit les changements
4. Push vers la branche
5. Ouvrir une Pull Request

## 📄 Licence

MIT License - voir le fichier LICENSE pour plus de détails.